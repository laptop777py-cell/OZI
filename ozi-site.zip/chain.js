/* LangChain.js orchestration: prompt templating + chat history + a runnable chain that hands the
   assembled messages to Ozi's router (on-device model / free cloud / rules). Runs in the page. */
import { ChatPromptTemplate, MessagesPlaceholder } from 'https://esm.sh/@langchain/core@0.3/prompts';
import { RunnableLambda, RunnableSequence } from 'https://esm.sh/@langchain/core@0.3/runnables';
import { HumanMessage, AIMessage } from 'https://esm.sh/@langchain/core@0.3/messages';
import { InMemoryChatMessageHistory } from 'https://esm.sh/@langchain/core@0.3/chat_history';

const roleOf = m => { const t = typeof m.getType === 'function' ? m.getType() : (m._getType ? m._getType() : m.type); return t === 'human' ? 'user' : t === 'ai' ? 'assistant' : 'system'; };

export function createOrchestrator(run) {
  const history = new InMemoryChatMessageHistory();
  const prompt = ChatPromptTemplate.fromMessages([['system', '{system}'], new MessagesPlaceholder('history'), ['human', '{input}']]);
  const chain = RunnableSequence.from([
    prompt,
    RunnableLambda.from(async (promptValue, config) => {
      const msgs = promptValue.toChatMessages().map(m => ({ role: roleOf(m), content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content) }));
      return run(msgs, (config && config.configurable) || {});
    })
  ]);
  return {
    kind: 'langchain',
    async ask(input, system, cfg) {
      const past = await history.getMessages();
      const out = await chain.invoke({ system, history: past.slice(-20), input }, { configurable: cfg || {} });
      await history.addMessage(new HumanMessage(input));
      await history.addMessage(new AIMessage(String(out)));
      const all = await history.getMessages();
      if (all.length > 40) { await history.clear(); for (const m of all.slice(-24)) await history.addMessage(m); }
      return out;
    },
    async seed(pairs) {
      await history.clear();
      for (const p of pairs) await history.addMessage(p.role === 'user' ? new HumanMessage(p.content) : new AIMessage(p.content));
    },
    async reset() { await history.clear(); }
  };
}
