// Paste your Google "Web application" OAuth client ID between the quotes, then save (commit) this file.
window.OZI_CONFIG = { googleWebClientId: '' };
