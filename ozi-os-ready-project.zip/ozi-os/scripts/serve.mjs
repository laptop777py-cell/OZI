// Tiny static server for dist/ (development and preview).   node scripts/serve.mjs [--watch]   PORT=8080
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), dist = path.join(root, 'dist'), port = Number(process.env.PORT) || 8080;
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.wasm': 'application/wasm', '.svg': 'image/svg+xml' };
const build = () => { const r = spawnSync(process.execPath, [path.join(root, 'scripts', 'build.mjs')], { stdio: 'inherit' }); return r.status === 0; };
if (!fs.existsSync(dist) && !build()) process.exit(1);
http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname); if (p.endsWith('/')) p += 'index.html';
  const f = path.normalize(path.join(dist, p));
  if (!f.startsWith(dist) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404).end('Not found'); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  fs.createReadStream(f).pipe(res);
}).listen(port, () => console.log(`Ozi OS: http://localhost:${port}`));
if (process.argv.includes('--watch')) {
  let t; const again = () => { clearTimeout(t); t = setTimeout(() => { console.log('Rebuilding...'); build(); }, 250); };
  for (const d of ['src', 'public']) fs.watch(path.join(root, d), { recursive: true }, again);
  console.log('Watching src/ and public/ for changes.');
}
