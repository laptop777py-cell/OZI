// Run after `npx cap add android`: installs the native plugin, permissions and package queries.
const fs = require('fs');
const path = require('path');

const main = path.join('android', 'app', 'src', 'main');
const pkgDir = path.join(main, 'java', 'com', 'ozi', 'os');
fs.mkdirSync(pkgDir, { recursive: true });
fs.copyFileSync(path.join('src', 'native', 'OziNativePlugin.java'), path.join(pkgDir, 'OziNativePlugin.java'));
fs.copyFileSync(path.join('src', 'native', 'MainActivity.java'), path.join(pkgDir, 'MainActivity.java'));

const mf = path.join(main, 'AndroidManifest.xml');
let m = fs.readFileSync(mf, 'utf8');

const perms = [
  'android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.RECORD_AUDIO', 'android.permission.MODIFY_AUDIO_SETTINGS',
  'android.permission.CAMERA',
  'android.permission.ACCESS_FINE_LOCATION', 'android.permission.ACCESS_COARSE_LOCATION',
  'com.android.alarm.permission.SET_ALARM'
];
const missing = perms.filter(p => !m.includes('android:name="' + p + '"'));
if (missing.length) m = m.replace('</manifest>', missing.map(p => '    <uses-permission android:name="' + p + '" />').join('\n') + '\n</manifest>');
if (!m.includes('android.hardware.camera')) m = m.replace('</manifest>', '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n</manifest>');

if (!m.includes('<queries>')) {
  const q = [
    '    <queries>',
    '        <intent><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent>',
    '        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>',
    '        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="mailto" /></intent>',
    '        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="sms" /></intent>',
    '        <intent><action android:name="android.intent.action.DIAL" /></intent>',
    '        <intent><action android:name="android.speech.RecognitionService" /></intent>',
    '        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>',
    '    </queries>', ''
  ].join('\n');
  m = m.replace(/(\s*)<application/, '\n' + q + '    <application');
}
if (!m.includes('usesCleartextTraffic')) m = m.replace('<application', '<application android:usesCleartextTraffic="true"');
if (!m.includes('windowSoftInputMode')) m = m.replace('<activity', '<activity android:windowSoftInputMode="adjustResize"');

fs.writeFileSync(mf, m);
console.log('Android project patched: plugin, permissions (camera, mic, location, alarm), queries, cleartext, keyboard resize.');
