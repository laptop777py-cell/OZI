// Fails when anything in the frontend (src, public, dist) looks like an API key or secret, or still depends on Claude's Artifact runtime.
//   node scripts/check-secrets.mjs
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PATTERNS = [
  [/sk-ant-[A-Za-z0-9_-]{10,}/, 'Anthropic API key'],
  [/\bsk-[A-Za-z0-9]{20,}/, 'OpenAI-style API key'],
  [/AIza[0-9A-Za-z_-]{30,}/, 'Google API key'],
  [/GOCSPX-[0-9A-Za-z_-]{10,}/, 'Google OAuth client secret'],
  [/\bhf_[A-Za-z0-9]{30,}/, 'Hugging Face token'],
  [/\bgh[pousr]_[A-Za-z0-9]{30,}/, 'GitHub token'],
  [/\bxox[abp]-[0-9A-Za-z-]{10,}/, 'Slack token'],
  [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, 'private key'],
  [/client_secret\s*[:=]\s*['"][^'"]{8,}/i, 'hard-coded client secret'],
  [/\b[A-Z0-9_]*(?:API_KEY|SECRET|TOKEN)\s*[:=]\s*['"][A-Za-z0-9_\-]{16,}['"]/, 'hard-coded key/secret/token']
];
const ARTIFACT = [[/window\.claude\b/, 'Claude Artifact runtime (window.claude)'], [/\bclaude\.use\(/, 'Claude Artifact runtime (claude.use)']];
const ALLOWED_CONFIG_KEYS = new Set(['googleWebClientId', 'apiBase']);

function walk(p, out = []) {
  if (!fs.existsSync(p)) return out;
  const st = fs.statSync(p);
  if (st.isFile()) { out.push(p); return out; }
  for (const f of fs.readdirSync(p)) { if (['node_modules', '.git', 'android', 'ort'].includes(f)) continue; walk(path.join(p, f), out); }
  return out;
}
export function scan(dirs) {
  const problems = [];
  for (const d of dirs) for (const f of walk(d)) {
    if (!/\.(js|mjs|cjs|html|css|json|md|txt|yml|yaml|toml)$/.test(f)) continue;
    const text = fs.readFileSync(f, 'utf8');
    for (const [re, name] of PATTERNS) if (re.test(text)) problems.push(`${path.relative(process.cwd(), f)}: ${name}`);
    if (/[\\/](src|dist)[\\/]/.test(f) && /\.(js|html)$/.test(f)) for (const [re, name] of ARTIFACT) if (re.test(text)) problems.push(`${path.relative(process.cwd(), f)}: ${name}`);
    if (path.basename(f) === 'config.js' && /dist/.test(f)) {
      const m = text.match(/window\.OZI_CONFIG\s*=\s*(\{[\s\S]*?\});/);
      try { for (const k of Object.keys(JSON.parse(m[1]))) if (!ALLOWED_CONFIG_KEYS.has(k)) problems.push(`${path.relative(process.cwd(), f)}: config key "${k}" is not an allowed public setting`); }
      catch (e) { problems.push(`${path.relative(process.cwd(), f)}: unreadable config`); }
    }
  }
  return problems;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  const bad = scan(['src', 'public', 'dist', 'README.md', 'docs', '.github', 'capacitor.config.json', 'package.json'].map(x => path.join(root, x)));
  if (bad.length) { console.error('Possible secrets or Artifact-only code found:'); bad.forEach(b => console.error(' ', b)); process.exit(1); }
  console.log('No secrets or Artifact-only code found in the frontend (src, public, dist, docs, workflows).');
}
