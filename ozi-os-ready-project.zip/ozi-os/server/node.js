// Node 18+ entry (VPS, Render, Railway, Fly...). Run with:  node server/node.js   (secrets come from environment variables)
import http from 'node:http';
import { handle } from './handler.js';
const port = Number(process.env.PORT) || 8787;
http.createServer(async (req, res) => {
  try {
    const chunks = []; let size = 0;
    for await (const c of req) { size += c.length; if (size > 65536) { res.writeHead(413).end(); return; } chunks.push(c); }
    const request = new Request(`http://${req.headers.host || 'localhost'}${req.url}`, { method: req.method, headers: req.headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : Buffer.concat(chunks) });
    const out = await handle(request, process.env);
    res.writeHead(out.status, Object.fromEntries(out.headers));
    res.end(Buffer.from(await out.arrayBuffer()));
  } catch (e) { res.writeHead(500, { 'Content-Type': 'application/json' }).end('{"error":"server_error"}'); }
}).listen(port, () => console.log(`Ozi OS server listening on :${port}`));
