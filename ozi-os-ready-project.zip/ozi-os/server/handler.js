/* Ozi OS server: the ONLY place that holds secrets (Google client secret, session secret, LLM and search API keys).
   One portable handler: Cloudflare Workers, Deno, Bun and Node 18+ (see worker.js and node.js). No dependencies.

   Endpoints
     GET  /api/health                  public: which features are configured (never any secret)
     POST /api/session                 body {id_token}: verifies a Google ID token, returns a signed 30-day session token
     POST /api/google/device/code      Android sign-in step 1 (adds the client id; scope is fixed to openid email profile)
     POST /api/google/token            Android sign-in step 2 / refresh (adds the client secret on the server)
     POST /api/chat    (session)       body {messages}: forwards to your LLM provider with the key kept here
     POST /api/search  (session)       body {q}: web search through your search provider
*/
const enc = new TextEncoder(), dec = new TextDecoder();
const SESSION_DAYS = 30, MAX_BODY = 64 * 1024, RATE_PER_MIN = 30;

class HttpError extends Error { constructor(status, code) { super(code); this.status = status; this.code = code; } }
const list = v => String(v || '').split(',').map(x => x.trim()).filter(Boolean);
const b64u = bytes => { const u = new Uint8Array(bytes); let s = ''; for (let i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
const fromB64u = s => { s = String(s).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return Uint8Array.from(atob(s), c => c.charCodeAt(0)); };
const SEC_HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
const json = (obj, status = 200, extra = {}) => new Response(JSON.stringify(obj), { status, headers: { ...SEC_HEADERS, ...extra } });

/* ---------- CORS: only your own origins may call the API from a browser ---------- */
function cors(req, env) {
  const origin = req.headers.get('Origin'), allow = list(env.ALLOWED_ORIGINS), headers = { Vary: 'Origin' };
  if (!origin) return { ok: true, headers };                       // native app / curl: no Origin header
  const ok = allow.includes('*') || allow.includes(origin);
  if (ok) Object.assign(headers, { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Headers': 'Authorization, Content-Type', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS', 'Access-Control-Max-Age': '86400' });
  return { ok, headers };
}
async function readBody(req) {
  const text = await req.text();
  if (text.length > MAX_BODY) throw new HttpError(413, 'body_too_large');
  if (!text) return {};
  const type = req.headers.get('Content-Type') || '';
  try {
    if (type.includes('application/x-www-form-urlencoded')) return Object.fromEntries(new URLSearchParams(text));
    return JSON.parse(text);
  } catch (e) { throw new HttpError(400, 'bad_body'); }
}

/* ---------- session tokens (HMAC-SHA256, signed with SESSION_SECRET) ---------- */
const hmacKey = secret => crypto.subtle.importKey('raw', enc.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
function needSecret(env) { if (!env.SESSION_SECRET || String(env.SESSION_SECRET).length < 32) throw new HttpError(500, 'server_misconfigured'); return env.SESSION_SECRET; }
async function signSession(payload, secret) {
  const body = b64u(enc.encode(JSON.stringify(payload))), sig = await crypto.subtle.sign('HMAC', await hmacKey(secret), enc.encode(body));
  return 'v1.' + body + '.' + b64u(sig);
}
async function readSession(token, secret) {
  const [v, body, sig] = String(token || '').split('.');
  if (v !== 'v1' || !body || !sig) return null;
  try {
    if (!(await crypto.subtle.verify('HMAC', await hmacKey(secret), fromB64u(sig), enc.encode(body)))) return null;
    const p = JSON.parse(dec.decode(fromB64u(body)));
    return p.exp > Date.now() / 1000 ? p : null;
  } catch (e) { return null; }
}
async function requireSession(req, env) {
  const m = /^Bearer\s+(\S+)$/.exec(req.headers.get('Authorization') || '');
  const p = m && await readSession(m[1], needSecret(env));
  if (!p) throw new HttpError(401, 'unauthorized');
  return p;
}

/* ---------- Google ID token verification (signature, issuer, audience, expiry, verified email, optional allow-list) ---------- */
let jwks = { at: 0, keys: null };
async function googleKeys() {
  if (jwks.keys && Date.now() - jwks.at < 600000) return jwks.keys;
  const r = await fetch('https://www.googleapis.com/oauth2/v3/certs');
  if (!r.ok) throw new HttpError(502, 'upstream_error');
  jwks = { at: Date.now(), keys: (await r.json()).keys || [] };
  return jwks.keys;
}
async function verifyGoogle(idToken, env) {
  const parts = String(idToken || '').split('.');
  if (parts.length !== 3) throw new HttpError(401, 'bad_token');
  let header, p;
  try { header = JSON.parse(dec.decode(fromB64u(parts[0]))); p = JSON.parse(dec.decode(fromB64u(parts[1]))); } catch (e) { throw new HttpError(401, 'bad_token'); }
  const auds = [env.GOOGLE_WEB_CLIENT_ID, env.GOOGLE_CLIENT_ID].filter(Boolean);
  if (header.alg !== 'RS256' || !['https://accounts.google.com', 'accounts.google.com'].includes(p.iss) || !auds.includes(p.aud) || !(p.exp > Date.now() / 1000 - 30)) throw new HttpError(401, 'bad_token');
  if (!p.email || (p.email_verified !== true && p.email_verified !== 'true')) throw new HttpError(401, 'email_not_verified');
  const jwk = (await googleKeys()).find(k => k.kid === header.kid);
  if (!jwk) throw new HttpError(401, 'bad_token');
  const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  if (!(await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, fromB64u(parts[2]), enc.encode(parts[0] + '.' + parts[1])))) throw new HttpError(401, 'bad_token');
  const allow = list(env.ALLOWED_EMAILS).map(x => x.toLowerCase());
  if (allow.length && !allow.includes(String(p.email).toLowerCase())) throw new HttpError(403, 'account_not_allowed');
  return p;
}

/* ---------- per-user rate limit (best effort, in memory) ---------- */
const hits = new Map();
function rateLimit(sub) {
  const now = Date.now(), arr = (hits.get(sub) || []).filter(t => now - t < 60000);
  if (arr.length >= RATE_PER_MIN) throw new HttpError(429, 'rate_limited');
  arr.push(now); hits.set(sub, arr);
  if (hits.size > 5000) hits.clear();
}

/* ---------- Google OAuth (device flow): the client secret is added HERE ---------- */
async function googleForm(url, fields) {
  const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(fields).toString() });
  let j = {}; try { j = await r.json(); } catch (e) { throw new HttpError(502, 'upstream_error'); }
  return { status: r.status, body: j };
}

/* ---------- chat ---------- */
function cleanMessages(msgs) {
  if (!Array.isArray(msgs) || !msgs.length || msgs.length > 40) throw new HttpError(400, 'bad_messages');
  let total = 0;
  return msgs.map(m => {
    if (!m || !['system', 'user', 'assistant'].includes(m.role) || typeof m.content !== 'string') throw new HttpError(400, 'bad_messages');
    const content = m.content.slice(0, 8000); total += content.length;
    if (total > 24000) throw new HttpError(400, 'too_long');
    return { role: m.role, content };
  });
}
async function chat(msgs, maxTokens, env) {
  const provider = env.LLM_PROVIDER || (env.ANTHROPIC_API_KEY ? 'anthropic' : 'openai');
  if (provider === 'anthropic') {
    if (!env.ANTHROPIC_API_KEY) throw new HttpError(501, 'chat_not_configured');
    const system = msgs.filter(m => m.role === 'system').map(m => m.content).join('\n\n'), turns = [];
    for (const m of msgs.filter(x => x.role !== 'system')) {
      if (turns.length && turns[turns.length - 1].role === m.role) turns[turns.length - 1].content += '\n\n' + m.content; else turns.push({ role: m.role, content: m.content });
    }
    while (turns.length && turns[0].role !== 'user') turns.shift();
    const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' }, body: JSON.stringify({ model: env.LLM_MODEL || 'claude-sonnet-5-5', max_tokens: maxTokens, system, messages: turns }) });
    if (!r.ok) throw new HttpError(502, 'upstream_error');
    const j = await r.json();
    return (j.content || []).map(b => b.text || '').join('');
  }
  const key = env.OPENAI_API_KEY || env.LLM_API_KEY;
  if (!key) throw new HttpError(501, 'chat_not_configured');
  const r = await fetch((env.LLM_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, '') + '/chat/completions', { method: 'POST', headers: { Authorization: 'Bearer ' + key, 'content-type': 'application/json' }, body: JSON.stringify({ model: env.LLM_MODEL || 'gpt-4o-mini', max_tokens: maxTokens, messages: msgs }) });
  if (!r.ok) throw new HttpError(502, 'upstream_error');
  const j = await r.json();
  return (j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '';
}

/* ---------- search (Brave Search API) ---------- */
async function search(q, env) {
  if (!env.BRAVE_API_KEY) throw new HttpError(501, 'search_not_configured');
  const r = await fetch('https://api.search.brave.com/res/v1/web/search?count=6&q=' + encodeURIComponent(q), { headers: { Accept: 'application/json', 'X-Subscription-Token': env.BRAVE_API_KEY } });
  if (!r.ok) throw new HttpError(502, 'upstream_error');
  const j = await r.json();
  return ((j.web && j.web.results) || []).slice(0, 6).map(x => ({ title: String(x.title || '').slice(0, 200), url: x.url, snippet: String(x.description || '').slice(0, 400) }));
}

export async function handle(req, env) {
  env = env || {};
  const url = new URL(req.url), c = cors(req, env);
  if (req.method === 'OPTIONS') return new Response(null, { status: c.ok ? 204 : 403, headers: c.headers });
  if (!c.ok) return json({ error: 'origin_not_allowed' }, 403, c.headers);
  try {
    if (url.pathname === '/api/health' && req.method === 'GET')
      return json({ ok: true, features: { session: !!env.SESSION_SECRET, google: !!(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET), chat: !!(env.ANTHROPIC_API_KEY || env.OPENAI_API_KEY || env.LLM_API_KEY), search: !!env.BRAVE_API_KEY } }, 200, c.headers);
    if (req.method !== 'POST') throw new HttpError(405, 'method_not_allowed');
    const body = await readBody(req);
    switch (url.pathname) {
      case '/api/session': {
        const secret = needSecret(env), p = await verifyGoogle(body.id_token, env), exp = Math.floor(Date.now() / 1000) + SESSION_DAYS * 86400;
        return json({ session: await signSession({ sub: p.sub, email: p.email, exp }, secret), expires: exp }, 200, c.headers);
      }
      case '/api/google/device/code': {
        if (!env.GOOGLE_CLIENT_ID) throw new HttpError(501, 'google_not_configured');
        const r = await googleForm('https://oauth2.googleapis.com/device/code', { client_id: env.GOOGLE_CLIENT_ID, scope: 'openid email profile' });
        return json({ ...r.body, client_id: env.GOOGLE_CLIENT_ID }, r.status, c.headers);
      }
      case '/api/google/token': {
        if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) throw new HttpError(501, 'google_not_configured');
        const f = { client_id: env.GOOGLE_CLIENT_ID, client_secret: env.GOOGLE_CLIENT_SECRET };
        if (body.grant_type === 'device_code' && typeof body.device_code === 'string' && body.device_code.length < 2048) Object.assign(f, { code: body.device_code, grant_type: 'http://oauth.net/grant_type/device/1.0' });
        else if (body.grant_type === 'refresh_token' && typeof body.refresh_token === 'string' && body.refresh_token.length < 2048) Object.assign(f, { refresh_token: body.refresh_token, grant_type: 'refresh_token' });
        else throw new HttpError(400, 'bad_request');
        const r = await googleForm('https://oauth2.googleapis.com/token', f);
        delete r.body.access_token;                                  // the app only needs the ID token and refresh token
        return json(r.body, r.status, c.headers);
      }
      case '/api/chat': {
        const s = await requireSession(req, env); rateLimit(s.sub);
        const text = await chat(cleanMessages(body.messages), Math.min(Math.max(parseInt(body.max_tokens) || 700, 50), 1024), env);
        return json({ text }, 200, c.headers);
      }
      case '/api/search': {
        const s = await requireSession(req, env); rateLimit(s.sub);
        const q = String(body.q || '').trim().slice(0, 300);
        if (!q) throw new HttpError(400, 'bad_request');
        return json({ results: await search(q, env) }, 200, c.headers);
      }
      default: throw new HttpError(404, 'not_found');
    }
  } catch (e) {
    return json({ error: e instanceof HttpError ? e.code : 'server_error' }, e instanceof HttpError ? e.status : 500, c.headers);
  }
}
