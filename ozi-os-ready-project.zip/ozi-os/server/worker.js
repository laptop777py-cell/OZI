// Cloudflare Workers entry. Deploy with:  cd server && npx wrangler deploy
import { handle } from './handler.js';
export default { fetch: (request, env) => handle(request, env) };
