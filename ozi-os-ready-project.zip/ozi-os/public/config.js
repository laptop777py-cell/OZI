// PUBLIC settings only. This file is downloaded by every visitor, so NEVER put an API key or a client secret here.
// `npm run build` regenerates it from OZI_GOOGLE_WEB_CLIENT_ID and OZI_API_BASE (see .env.example).
window.OZI_CONFIG = { googleWebClientId: '', apiBase: '' };
