/* Ozi OS service worker. Caches the app files and the pinned CDN libraries after first use, so the installed web app
   opens and runs offline. AI models are cached by the engine itself (Cache Storage); Google, model downloads and APIs are never touched. */
const V = 'ozi-shell-__VERSION__';
const CDN = ['cdn.jsdelivr.net', 'esm.sh'];
self.addEventListener('install', e => {
  self.skipWaiting();
  e.waitUntil(caches.open(V).then(c => c.addAll(['./', 'index.html', 'app.css', 'app.js', 'manifest.json', 'icon-192.png', 'icon-512.png']).catch(() => {})));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith('ozi-shell-') && k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET') return;
  const u = new URL(r.url), same = u.origin === location.origin, cdn = CDN.includes(u.hostname);
  if (!same && !cdn) return;
  e.respondWith(caches.open(V).then(async c => {
    const hit = await c.match(r, { ignoreSearch: false });
    if (hit && cdn) return hit;                                // pinned library versions: cache first
    const net = fetch(r).then(res => { if (res && res.ok) c.put(r, res.clone()); return res; }).catch(() => hit);
    return hit || net;                                         // app files: cache first, refresh in the background
  }));
});
