# Ozi OS — phone-friendly deployment guide

## What is ready
- `dist/` is a built static website/PWA.
- `npm test` passes all 165 checks.
- `.github/workflows/pages.yml` deploys the website to GitHub Pages on push to `main`/`master` or via Actions → Run workflow.
- `.github/workflows/android.yml` builds a debug APK in GitHub Actions when manually run.
- No Anthropic API key is included. Do not put API keys in `public/config.js`, `.env` values that are committed, or any frontend file.

## Publish the website

### If you can use a computer later
1. Upload the contents of this project to a GitHub repository.
2. In GitHub, open Settings → Pages and set Source to **GitHub Actions**.
3. Open Settings → Secrets and variables → Actions → Variables and add `OZI_GOOGLE_WEB_CLIENT_ID` if Google sign-in is needed. Add `OZI_API_BASE` only after you deploy the optional backend.
4. Open Actions → **Deploy website to GitHub Pages** → Run workflow.
5. Wait for success, then open the Pages URL shown by GitHub.

### Static preview
The `dist/` folder is already built and can be deployed to any static HTTPS host. It can be opened locally for a limited preview, but browser security restrictions mean camera, microphone, sign-in and PWA/offline features need HTTPS hosting.

## Build a debug APK from GitHub Actions
1. Upload the full project (including the `.github/workflows/` folder) to a GitHub repository on branch `main` or `master.
2. Open the repository → Settings → Secrets and variables → Actions → Variables. Add `OZI_API_BASE` only if an Ozi backend has already been deployed. Leave it unset otherwise.
3. Open Actions → **Build Android APK (debug)** → Run workflow.
4. Wait for the workflow to finish. Open its completed run, scroll to **Artifacts**, and download `OziOS-debug-apk`.
5. Extract the downloaded artifact ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that browser/files app. Only install APKs you built or trust.

## AI notes
- The app does not automatically inherit Claude Artifact's built-in model access.
- To use Claude through the app's proxy, deploy the optional `server/` backend and configure `ANTHROPIC_API_KEY` as a server-side secret. Never put that key in the website or APK.
- The app can also use its other supported model routes, depending on availability and configuration.
- Google sign-in and Android native features need real-device testing and configuration; the source project's README has the full setup details.

## Important limitations
- The APK workflow builds a **debug APK for testing**, not a Play Store release.
- This project was tested with 165 automated checks and the static web build completed. The Android SDK/device build has not been run in this environment, so test the downloaded APK on your phone.
