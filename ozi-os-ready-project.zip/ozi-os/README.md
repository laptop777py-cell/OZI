# Ozi OS

A voice-first AI assistant that runs as a **website (installable PWA)** and as an **Android app (Capacitor)** from one codebase.
Sign-in is a real Google account only. Models run on the device (download once, work offline) or in free cloud services. Secrets never touch the frontend.

Preserved from the Artifact: the particle-sphere orb UI, Wixu / Wiu personalities (Jarvis-style spoken manner), voice in/out (ElevenLabs, offline Kokoro, device voice),
on-device models + Whisper + camera "eyes", model library with "add any Hugging Face / GitHub model", image generation, memory, reminders, briefings,
phone actions, Home Assistant, one-time permissions, encrypted on-device storage, chat history, and every setting in the ring (°) menu.

## Project layout
```
ozi-os/
├─ src/
│  ├─ templates/        index.html (shell) + body.html (all markup)
│  ├─ styles/app.css    the design (unchanged from the Artifact)
│  ├─ js/               00-pure.js (parsers, token checks) · 10-core.js (orb, UI) · 20-services.js (network, search, auth, models)
│  │                    · 30-assistant.js (voice, router, intents, menu, boot). Concatenated in order by the build.
│  ├─ engine/           worker.cdn.js / chain.cdn.js (web) and worker.npm.js / chain.npm.js (bundled for Android)
│  └─ native/           Java plugin: open apps, links, dialer, alarms, timers
├─ public/              manifest.json, icons, sw.js (offline), config.js (PUBLIC settings), _headers
├─ server/              OPTIONAL backend that holds every secret (Cloudflare Worker or Node)
├─ scripts/             build.mjs · serve.mjs · check-secrets.mjs · patch-android.cjs
├─ tests/               165 checks: parsers, app logic, sign-in flows, server
├─ docs/                ARTIFACT-DEPENDENCIES.md
├─ .github/workflows/   ci.yml · pages.yml · android.yml
├─ capacitor.config.json · package.json · .env.example
```
The frontend is plain HTML/CSS/JavaScript. The Artifact contained no React, so none is added; nothing about the design or behaviour needed it.

## Requirements
Node 20+. For the Android app also: JDK 17 and the Android SDK (Android Studio, SDK Platform 34). Everything else installs with `npm install`.

## Quick start
```bash
npm install
npm test            # 165 checks, no network needed
npm run dev         # builds, serves http://localhost:8080 and rebuilds on every change
```
Google sign-in will say "not set up" until you add the public settings below.

## Configure
Only **public** values go in the frontend. Copy `.env.example` to `.env`:

| Variable (public) | What it is |
|---|---|
| `OZI_GOOGLE_WEB_CLIENT_ID` | Google "Web application" OAuth client ID (website sign-in). Public by design. |
| `OZI_API_BASE` | URL of your Ozi server, e.g. `https://ozi-os-server.you.workers.dev` (Android sign-in, server chat and search) |

`npm run build` writes them into `dist/config.js`, and **refuses to build** if anything that looks like a secret is in the output (`npm run check:secrets` runs the same scan).

### Google sign-in (once)
1. console.cloud.google.com → new project → APIs & Services → OAuth consent screen: External, then **Publish app** (otherwise Google ends sign-ins every 7 days).
2. **Website**: Credentials → Create credentials → OAuth client ID → *Web application* → Authorized JavaScript origins: your site's origin (e.g. `https://you.github.io`, and `http://localhost:8080` for development). Put the ID in `OZI_GOOGLE_WEB_CLIENT_ID`.
3. **Android app**: a second client of type *TVs and Limited Input devices*. Its ID **and secret go on the server only** (`GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, below).
The ID token is verified on the device and again on the server (signature, issuer, audience, expiry, verified email).

## Server (holds the secrets)
Needed for: Android sign-in, optional Claude/OpenAI chat route, optional web search. The website alone works without it (Google button, free cloud models, on-device models, Wikipedia search).
Endpoints: `GET /api/health`, `POST /api/session`, `/api/google/device/code`, `/api/google/token`, `/api/chat`, `/api/search`. Chat and search require a session issued after Google sign-in, are rate-limited per user, and can be limited to listed Google accounts (`ALLOWED_EMAILS`).

**Option A: Cloudflare Workers (free tier)**
```bash
cd server
# edit wrangler.toml: ALLOWED_ORIGINS (your site origin + https://localhost + capacitor://localhost)
npx wrangler login
openssl rand -hex 32 | npx wrangler secret put SESSION_SECRET
npx wrangler secret put GOOGLE_CLIENT_ID
npx wrangler secret put GOOGLE_CLIENT_SECRET
npx wrangler secret put GOOGLE_WEB_CLIENT_ID
npx wrangler secret put ANTHROPIC_API_KEY     # or OPENAI_API_KEY (+ LLM_PROVIDER=openai) ; optional
npx wrangler secret put BRAVE_API_KEY         # optional (web search)
npx wrangler deploy                           # prints https://ozi-os-server.<you>.workers.dev
curl https://ozi-os-server.<you>.workers.dev/api/health
```
**Option B: any Node 18+ host**: set the same variables in its dashboard and run `node server/node.js` (listens on `$PORT`, default 8787).
Put the resulting URL in `OZI_API_BASE`. Never commit real values; `.env`, `.dev.vars` and keystores are git-ignored.

## Build and deploy the website
```bash
npm run build       # -> dist/  (static files; ~0.5 MB)
```
Deploy `dist/` to any static host over **HTTPS** (needed for sign-in, camera, microphone and the PWA):
* **GitHub Pages**: push to GitHub, Settings → Pages → Source: *GitHub Actions*, add repository Variables `OZI_GOOGLE_WEB_CLIENT_ID` and `OZI_API_BASE`; `pages.yml` builds and deploys.
* **Netlify / Cloudflare Pages / Vercel**: build command `npm run build`, output directory `dist`, set the two variables in the dashboard. Netlify and Cloudflare also read `dist/_headers`.
* **Anywhere else**: upload the contents of `dist/`.
Add the final site origin to the Google Web client's Authorized JavaScript origins. In Chrome, menu → *Add to Home screen* installs it; after one visit it opens offline.
The web build loads Transformers.js / ONNX Runtime / Kokoro / LangChain from pinned CDN versions the first time and the service worker keeps them for offline use.

## Build the Android APK (Capacitor)
Prepare once: install JDK 17 and Android Studio (SDK Platform 34 + build-tools), set `ANDROID_HOME`, and put `OZI_API_BASE=https://your-server` in `.env`.
```bash
npm install
npm run cap:add        # builds the offline bundle (engine + ONNX Runtime inside the app), runs `cap add android`, patches manifest + native plugin
npm run android:debug  # builds dist, `cap sync`, then Gradle
# APK: android/app/build/outputs/apk/debug/app-debug.apk
adb install -r android/app/build/outputs/apk/debug/app-debug.apk     # or copy the file to the phone and open it
```
After changing code: `npm run cap:sync`, then rebuild. Android Studio: `npm run cap:open`.
**Release**: create a keystore once (`keytool -genkeypair -v -keystore ozi-release.jks -alias ozi -keyalg RSA -keysize 2048 -validity 10000`, keep it OUT of git),
then in Android Studio *Build → Generate Signed Bundle / APK*. Without CI secrets there is no store signing in the repository.
**Cloud build**: `.github/workflows/android.yml` produces the debug APK as a downloadable artifact (variable `OZI_API_BASE`).
The Java layer (`src/native`) adds: open installed apps by name, links, dialer, email/SMS drafts, alarms, timers. The manifest gets camera, microphone, location and alarm permissions.

## Tests
`npm test` runs: parsers and token verification, the app logic in a simulated browser (routing, permissions, memory, reminders, voice modes, downloads), every sign-in path (Android, website, refused account, offline, corrupted storage, file copy), the server (tokens, allow-list, CORS, rate limit, secrets never returned) and the secret scan.

## Security model
* **No secrets in the frontend.** The Google client secret, session secret and every LLM/search key exist only on the server. The page holds only a public client ID and the server URL; the build and `npm test` fail otherwise.
* **Credentials a user types** (ElevenLabs, Hugging Face, Pollinations, Home Assistant) are that user's own, stored encrypted on their device (AES-256-GCM, non-extractable key in IndexedDB), never in code or git.
* The server accepts browser calls only from `ALLOWED_ORIGINS`, signs sessions with HMAC-SHA256, caps request sizes, rate-limits per account and returns generic errors.
* Chat history, memory and the Google session are stored encrypted on the device. There is no database.

## Features that depended on Claude's Artifact environment
See [docs/ARTIFACT-DEPENDENCIES.md](docs/ARTIFACT-DEPENDENCIES.md): the hosted "preview brain" (`claude.use('sample')`), the Firecrawl search connector (`claude.use('mcp')`), the preview gate, and Artifact sandbox limits, each with its replacement.

## Limits (be aware)
* Written and unit-tested without an Android SDK or device: the **Capacitor build, the native Java plugin, real Google sign-in, real voices and real model downloads have not been run end to end**. Expect to fix small things on the first device run.
* Not possible for a normal app: unlocking the phone, controlling other apps' screens, listening after the app is closed, automating a PC, merging millions of models into one network (Ozi AI is a router over several free models).
* Free cloud services (Pollinations, Hugging Face router) can change or rate-limit; the router falls back to on-device models and basic rules.

## Troubleshooting
* *"Google sign-in is not set up in this build yet"*: `OZI_GOOGLE_WEB_CLIENT_ID` (website) or `OZI_API_BASE` (Android) was empty at build time.
* *Google button error / popup blocked*: the site's origin is missing from the Web client's Authorized JavaScript origins.
* *Android sign-in fails*: check `curl <OZI_API_BASE>/api/health` shows `"google":true`, and `ALLOWED_ORIGINS` contains `https://localhost`.
* *"--offline needs the dev dependencies"*: run `npm install` first.
* *Models will not start*: the device needs WebAssembly; WebGPU makes them faster. Try a smaller model (Qwen2.5 0.5B).
