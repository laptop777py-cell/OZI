# Features that depended on Claude's Artifact environment, and what replaced them

The Artifact ran inside claude.ai's sandbox, which injected a `window.claude` object and blocked most outside connections. Nothing in this project uses `window.claude`
(`npm run check:secrets` fails the build if it reappears). Each dependency below was replaced or removed.

| # | Artifact-only feature (what it was) | What it did in the Artifact | Replacement in this project |
|---|---|---|---|
| 1 | `window.claude` / `hosted()` / `waitClaude()` | Detected "running inside Claude" and switched the app into a design-preview mode with a demo link instead of a real sign-in | **Removed.** The app always requires a real Google sign-in. No demo or bypass path exists. |
| 2 | `claude.use('sample')` → `ROUTES.preview` | A free, key-less Claude model as the only available brain | **Router routes instead:** on-device models (`local`), free cloud (`poll`, `hf`), basic rules, plus an optional **`proxy` route** (`ROUTES.proxy` → `POST /api/chat` on *your* server). The server holds `ANTHROPIC_API_KEY` (or OpenAI-compatible key) and verifies the user's session first. To use Claude: set `ANTHROPIC_API_KEY` on the server. |
| 3 | `claude.use('mcp')` → Firecrawl connector (`fcSearch`) | Live web search through the viewer's connected Firecrawl account | **`proxySearch` → `POST /api/search`** (Brave Search; key on the server). Android additionally reads Google/DuckDuckGo/YouTube result pages directly; the website falls back to Wikipedia. To change provider, edit `search()` in `server/handler.js`. |
| 4 | `claude.use('user')` + `claude.use('db')` (earlier versions) | Claude-account identity and per-account storage | **Google sign-in + encrypted on-device vault** (and an optional signed server session). No database needed. |
| 5 | `claude.use('downloads')` (earlier versions) | Saving a copy of the page | Not needed: the site is hosted normally and `npm run build` produces the files. |
| 6 | Sandbox CSP: no outside network, only 4 script hosts, no remote images | Blocked Google sign-in, model downloads, cloud routes, generated images, ElevenLabs | **No sandbox.** Needs HTTPS hosting (sign-in, camera, mic, PWA). Optionally add a CSP at your host; allow `accounts.google.com`, `cdn.jsdelivr.net`, `esm.sh`, `huggingface.co`, your server, and `wasm-unsafe-eval`. |
| 7 | Capability declarations at publish time (`sample`, `mcp`, `user`, `db`, `downloads`) | Granted the page access to the Claude runtime | **Public settings in `config.js` / `.env`** (`OZI_GOOGLE_WEB_CLIENT_ID`, `OZI_API_BASE`) and server environment variables for secrets. |
| 8 | Single inline file (CSS + JS inside one HTML file) | Artifacts publish one self-contained page | **Separate files**, assembled by `scripts/build.mjs` into `dist/` with a content-hash cache-bust and a versioned service-worker cache. |
| 9 | claude.ai-hosted URL and sharing rules | The page lived on a private claude.ai link | **Your own hosting** (GitHub Pages, Netlify, Cloudflare Pages, Vercel) and an installable PWA; Android app via Capacitor. |
| 10 | Popup / camera / microphone limits of the sandboxed iframe | Camera and popups were often blocked | Work normally on HTTPS and in the Android WebView (permissions are declared in the manifest by `scripts/patch-android.cjs`). |

## Where each replacement lives
* Router and the `proxy` route: `src/js/30-assistant.js` (`routesFor`, `ROUTES.proxy`).
* Server calls and sessions: `src/js/20-services.js` (`apiCall`, `registerSession`, `proxySearch`).
* Server: `server/handler.js` (tested by `tests/server.test.mjs`).
* Public configuration: `public/config.js`, written by `scripts/build.mjs`.
