// Runs every test file and prints a summary.   npm test
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dir = path.dirname(fileURLToPath(import.meta.url));
let failed = 0, total = 0;
for (const f of ['pure.test.cjs', 'smoke.test.cjs', 'auth.test.cjs', 'server.test.mjs']) {
  const r = spawnSync(process.execPath, [path.join(dir, f)], { encoding: 'utf8' });
  const out = (r.stdout || '') + (r.stderr || ''), ok = (out.match(/^ok /gm) || []).length, bad = (out.match(/^FAIL /gm) || []).length;
  total += ok; if (r.status !== 0 || bad) { failed++; console.log(out); }
  console.log(`${r.status === 0 && !bad ? 'PASS' : 'FAIL'}  ${f.padEnd(18)} ${ok} checks`);
}
const s = spawnSync(process.execPath, [path.join(dir, '..', 'scripts', 'check-secrets.mjs')], { encoding: 'utf8' });
console.log(`${s.status === 0 ? 'PASS' : 'FAIL'}  secret scan        ${(s.stdout || s.stderr).trim().split('\n')[0]}`); if (s.status !== 0) { failed++; console.log(s.stderr); }
console.log(`\n${failed ? failed + ' test file(s) failed' : 'ALL TESTS PASSED'} (${total} checks)`);
process.exit(failed ? 1 : 0);
