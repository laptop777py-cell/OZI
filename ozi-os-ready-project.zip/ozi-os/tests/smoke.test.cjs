const H=require('./harness.cjs')();H.load();
const sandbox=H.sandbox,vm=require('vm');
const test=`(async()=>{
const R=[];const ok=(n,c,x)=>{R.push((c?'ok   ':'FAIL ')+n+(c?'':'  -> '+JSON.stringify(x)))};
const saved=[];const _sc=saveChat;saveChat=(c,t)=>{saved.push([c,t]);return _sc(c,t)};
authMode='device';vault.acct={sub:'1',email:'t@t.t'};enter();
consent=async()=>'allow';
ok('full() with account',full()===true);
// 1 cloud route + auto search
const _ws=webSearch;webSearch=async()=>({source:'DuckDuckGo',results:[{title:'SpaceX news',url:'https://e.com/a',snippet:'launch today'}]});
let seenBody=null;postJSON=async(u,h,b)=>{seenBody=b;return{choices:[{message:{content:'SpaceX launched today (source: SpaceX news).'}}]}};
await send('what is the latest news about spacex');
ok('cloud answer saved',saved.some(s=>s[0]==='a'&&/SpaceX launched/.test(s[1])),saved);
ok('web results injected into prompt',seenBody&&/Live web results/.test(seenBody.messages[0].content)&&/SpaceX news/.test(seenBody.messages[0].content));
ok('device context injected',/Device: time/.test(seenBody.messages[0].content)&&/battery 80%/.test(seenBody.messages[0].content));
ok('persona is WIXU',/WIXU/.test(seenBody.messages[0].content));
// 2 offline + local route
saved.length=0;navigator.onLine=false;
Eng.llmId='m1';Eng.call=async(t,p,o)=>{if(t==='gen'){o&&o.onTok&&o.onTok('Hi ');return{text:'Hi there from the device'}}return{}};
await send('tell me a joke');
ok('offline uses on-device model',saved.some(s=>s[0]==='a'&&/Hi there from the device/.test(s[1]))&&LASTROUTE==='on-device',[saved,LASTROUTE]);
// 3 rules fallback
saved.length=0;Eng.llmId=null;await send('what time is it');
ok('rules fallback answers time',saved.some(s=>s[0]==='a'&&/It is /.test(s[1])),saved);
// 4 limited mode blocks internet
navigator.onLine=true;vault.acct=null;saved.length=0;let called=0;postJSON=async()=>{called++;return{}};
await send('what is the latest news about mars');
ok('limited mode never calls cloud',called===0,called);
vault.acct={sub:'1'};
// 5 consent denial keeps it offline
vault.cfg.perm=undefined;consent=async()=>'deny';saved.length=0;called=0;postJSON=async()=>{called++;return{choices:[{message:{content:'x'}}]}};
await send('what is the latest news about venus');
ok('Stay offline blocks all internet',called===0,called);
consent=async()=>'allow';
// 5b one-time internet permission: "Always allow" is remembered, never asked again
vault.cfg.perm=undefined;let asked=0;consent=async()=>{asked++;return'allow'};postJSON=async()=>({choices:[{message:{content:'ok answer'}}]});
await send('what is the latest news about jupiter');await send('what is the latest news about saturn');
ok('internet asked once, then always allowed',asked===1&&vault.cfg.perm.net==='always',[asked,vault.cfg.perm]);
vault.cfg.perm.net='off';called=0;postJSON=async()=>{called++;return{}};await send('what is the latest news about neptune');
ok('Offline-only setting blocks the internet without asking',called===0&&asked===1,[called,asked]);
vault.cfg.perm.net='always';consent=async()=>'allow';
// 5c one-tap download: no extra confirmation, starts at once
Eng.caps={webgpu:false};Eng.probe=async()=>Eng.caps;let dlCalls=[];Eng.call=async(t,pl,o)=>{dlCalls.push(t);if(o&&o.onp)o.onp({file:'a',loaded:50,total:100});return{done:true}};
asked=0;await downloadModel('qwen25-05b');
ok('Download starts at once with no confirmation',asked===0&&dlCalls.includes('load-llm')&&Eng.llmId==='qwen25-05b',[asked,dlCalls,Eng.llmId]);
Eng.llmId=null;
// 5d Jarvis-style behaviour
vault.acct={sub:'1',email:'sam@x.y',name:'Sam Rivers'};
vault.cfg.address=undefined;saved.length=0;await send('status report');ok('default form of address is Sir',saved.some(s=>s[0]==='a'&&/All systems nominal, Sir/.test(s[1])),saved);
vault.cfg.address='name';
saved.length=0;await send('status report');ok('status report',saved.some(s=>s[0]==='a'&&/All systems nominal, Sam/.test(s[1])),saved);
webSearch=async()=>({source:'DuckDuckGo',results:[{title:'Headline A',url:'https://e.com/1',snippet:''},{title:'Headline B',url:'https://e.com/2',snippet:''}]});
getWeather=async()=>'Weather: 21 degrees, clear sky.';saved.length=0;await send('good morning');
ok('briefing has name, weather and headlines',saved.some(s=>s[0]==='a'&&/Sam/.test(s[1])&&/Weather: 21/.test(s[1])&&/Headline A/.test(s[1])),saved);
saved.length=0;await send('remind me in 1 second to stretch');
ok('reminder is stored',/stretch/.test(JSON.stringify(vault.reminders))&&saved.some(s=>/Reminder set/.test(s[1])),vault.reminders);
await new Promise(r=>setTimeout(r,1700));
ok('reminder fires and is removed',saved.some(s=>/Reminder: stretch/.test(s[1]))&&vault.reminders.length===0,[saved,vault.reminders]);
saved.length=0;await send('conversation mode');ok('conversation mode on',CONVO===true&&voiceOn===true);
let relistened=0;listen=()=>{relistened++};busy=false;state='speaking';setState('idle');await new Promise(r=>setTimeout(r,600));
ok('conversation mode listens again after speaking',relistened===1,relistened);
await send('goodbye');ok('goodbye ends conversation mode',CONVO===false);
// 5e Jarvis voice and personality
vault.cfg.address=undefined;mode='wixu';
ok('Wixu acknowledges like Jarvis',/^(Certainly|Right away|As you wish|Very good), Sir\. Opening YouTube\./.test(styleReply('Opening YouTube.')),styleReply('Opening YouTube.'));
ok('Wixu softens failures',styleReply('I could not find that app.')==="I'm afraid I could not find that app."&&styleReply('That did not work: x')==="I'm afraid that did not work: x");
vault.cfg.address='none';ok('no title option',/^(Certainly|Right away|As you wish|Very good)\. Opening/.test(styleReply('Opening X.')));vault.cfg.address=undefined;
mode='wiu';ok('Wiu is terse',styleReply('Opening YouTube.')==='Executed. Opening YouTube.');mode='wixu';
ok('prompt asks for a spoken Jarvis manner',/J\.A\.R\.V\.I\.S\./.test(PERSONAS.wixu.prompt)&&/no markdown/.test(PERSONAS.wixu.prompt)&&/{ADDRESS_RULE}/.test(PERSONAS.wixu.prompt));
ok('default voices: Henry for Wixu, Brian for Wiu',voiceName()==='Henry'&&(mode='wiu',voiceName())==='Brian',[voiceName()]);mode='wixu';vault.cfg.voice='Rachel';ok('chosen voice wins',voiceName()==='Rachel');vault.cfg.voice=undefined;
let spoken=0;speak=async()=>{spoken++};voiceOn=true;
vault.cfg.rv='always';inp.value='status report';spoken=0;await send();ok('text in, voice out (Always)',spoken===1,spoken);
vault.cfg.rv='spoken';inp.value='status report';spoken=0;await send();ok('text in, text out (Only when I speak)',spoken===0,spoken);
spoken=0;await send('status report');ok('voice in, voice out (Only when I speak)',spoken===1,spoken);
vault.cfg.rv='never';spoken=0;await send('status report');ok('Never speaks',spoken===0,spoken);
vault.cfg.rv='always';
// 5f server-backed routes (keys stay on the server)
window.OZI_CONFIG={apiBase:'https://api.example.com'};vault.acct={sub:'1',email:'sam@x.y',name:'Sam',session:'SESS-ABC'};vault.cfg.perm={net:'always'};
let seen=[];postJSON=async(u,h,b)=>{seen.push({u,h,b});if(/\\/api\\/chat/.test(u))return{text:'Certainly, Sir. From the server.'};if(/\\/api\\/search/.test(u))return{results:[{title:'Server result',url:'https://s.example/1',snippet:'x'}]};return{}};
saved.length=0;await send('explain why the sky is blue step by step');
ok('chat goes to your server with the session token (no API key in the page)',seen.some(c=>/\\/api\\/chat$/.test(c.u)&&c.h.Authorization==='Bearer SESS-ABC')&&saved.some(s=>/From the server/.test(s[1]))&&LASTROUTE==='Ozi AI server',[seen.map(c=>c.u),LASTROUTE]);
ok('no secret-looking value is ever sent besides the session',!JSON.stringify(seen).match(/sk-|client_secret|api[_-]?key/i),JSON.stringify(seen).slice(0,200));
webSearch=_ws;seen=[];const sr=await webSearch('latest rust release');ok('search goes through your server',sr.source==='Ozi search server'&&seen.some(c=>/\\/api\\/search$/.test(c.u)),sr);
window.OZI_CONFIG={};vault.acct.session='';
// 6 intents
saved.length=0;await send('set a timer for 5 minutes');ok('timer outside app is explained',saved.some(s=>/Android app/.test(s[1])),saved);
saved.length=0;await send('open eyes');ok('eyes open handles missing camera',saved.some(s=>/could not open the camera/.test(s[1])),saved);
saved.length=0;generateImage=async()=>'blob:img';await send('draw a picture of a neon cat');ok('image intent',saved.some(s=>/blob|image|Here is your image/.test(s[1])),saved);
saved.length=0;netGet=async()=>JSON.stringify({pipeline_tag:'text-generation',siblings:[{rfilename:'onnx/model_q4.onnx',size:4e8},{rfilename:'onnx/model_q4f16.onnx',size:3e8}]});
await send('add model onnx-community/Qwen2.5-Coder-0.5B-Instruct');ok('add HF model',vault.models.some(m=>m.hf==='onnx-community/Qwen2.5-Coder-0.5B-Instruct'&&m.dtype.wasm==='q4'&&m.dtype.webgpu==='q4f16'),[vault.models,saved]);
saved.length=0;await send('/build');ok('/build runs',saved.some(s=>s[0]==='a'&&/Build finished/.test(s[1])),saved);
saved.length=0;await send('remember that my favorite color is teal');ok('remember intent',/teal/.test(JSON.stringify(vault.mem)),vault.mem);
saved.length=0;await send('My name is Sam and I live in Dallas');ok('auto memory',vault.mem['name']&&vault.mem['lives in'],vault.mem);
await send('/mode wiu');ok('mode wiu',mode==='wiu');await send('/mode wixu');ok('mode wixu',mode==='wixu');
ok('image model picker lists free + HF models',imageChoices().length>=6&&imageChoices().some(x=>x[0]==='hf:black-forest-labs/FLUX.1-dev')&&imageChoices().some(x=>x[0]==='poll:flux'),imageChoices());
return R.join('\\n')})()`;
H.run(test).then(r=>{console.log(r);process.exit(/FAIL/.test(r)?1:0)}).catch(e=>{console.log('HARNESS ERROR',e&&e.stack||e);process.exit(2)});
setTimeout(()=>{console.log('TIMEOUT');process.exit(3)},60000);
