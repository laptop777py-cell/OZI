// Tests the server handler with every upstream service mocked. Verifies secrets are used server-side and never returned.
import { handle } from '../server/handler.js';
const R = []; const ok = (n, c, x) => R.push((c ? 'ok   ' : 'FAIL ') + n + (c ? '' : '  -> ' + JSON.stringify(x)));
const SECRETS = { SESSION_SECRET: 's3cr3t-session-'.repeat(3), GOOGLE_CLIENT_SECRET: 'TV-CLIENT-SECRET-VALUE-XYZ', ANTHROPIC_API_KEY: 'sk-ant-TESTKEY-1234567890', BRAVE_API_KEY: 'BRAVE-TEST-KEY-ABC' };
const ENV = { ...SECRETS, GOOGLE_CLIENT_ID: 'TVCID', GOOGLE_WEB_CLIENT_ID: 'WEBCID', ALLOWED_ORIGINS: 'https://me.github.io,https://localhost' };
const calls = [];
const kp = await crypto.subtle.generateKey({ name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' }, true, ['sign', 'verify']);
const jwk = await crypto.subtle.exportKey('jwk', kp.publicKey); jwk.kid = 'k1';
const e64 = o => Buffer.from(typeof o === 'string' ? o : JSON.stringify(o)).toString('base64url');
const idToken = async (over = {}) => { const s = e64({ alg: 'RS256', kid: 'k1' }) + '.' + e64({ iss: 'https://accounts.google.com', aud: 'WEBCID', sub: '42', email: 'sam@example.com', email_verified: true, exp: Math.floor(Date.now() / 1000) + 3600, ...over }); return s + '.' + Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5', kp.privateKey, Buffer.from(s))).toString('base64url'); };
globalThis.fetch = async (url, init = {}) => {
  url = String(url); calls.push({ url, init });
  if (url.includes('/oauth2/v3/certs')) return Response.json({ keys: [jwk] });
  if (url === 'https://oauth2.googleapis.com/device/code') return Response.json({ device_code: 'DC', user_code: 'ABCD-EFGH', verification_url: 'https://www.google.com/device', interval: 5, expires_in: 1800 });
  if (url === 'https://oauth2.googleapis.com/token') { const b = String(init.body); if (b.includes('PENDING')) return Response.json({ error: 'authorization_pending' }, { status: 428 }); return Response.json({ id_token: 'IDT', access_token: 'AT-SHOULD-NOT-LEAK', refresh_token: 'RT1' }); }
  if (url.startsWith('https://api.anthropic.com/')) return Response.json({ content: [{ type: 'text', text: 'Certainly, Sir.' }] });
  if (url.startsWith('https://api.search.brave.com/')) return Response.json({ web: { results: [{ title: 'A', url: 'https://a.example', description: 'desc' }] } });
  return new Response('unexpected', { status: 500 });
};
const call = (path, { method = 'POST', body, headers = {}, env = ENV, raw } = {}) => handle(new Request('https://api.example.com' + path, { method, headers: { 'Content-Type': 'application/json', ...headers }, body: raw ?? (body === undefined ? undefined : JSON.stringify(body)) }), env);
const text = async r => await r.text();
const leaks = s => Object.values(SECRETS).some(v => s.includes(v));

// health
let r = await call('/api/health', { method: 'GET' }); let t = await text(r);
ok('health: features reported, no secret in the response', r.status === 200 && JSON.parse(t).features.chat === true && !leaks(t), t);
// CORS
r = await call('/api/health', { method: 'OPTIONS', headers: { Origin: 'https://me.github.io' } });
ok('CORS: your origin is allowed', r.status === 204 && r.headers.get('Access-Control-Allow-Origin') === 'https://me.github.io');
r = await call('/api/health', { method: 'GET', headers: { Origin: 'https://evil.example' } });
ok('CORS: other origins are refused', r.status === 403);
r = await call('/api/health', { method: 'GET' }); ok('no Origin header (native app) is accepted', r.status === 200);
// session
r = await call('/api/session', { body: { id_token: await idToken() } }); const sess = JSON.parse(await text(r)).session;
ok('session: real Google token (audience matches) gives a signed session', r.status === 200 && /^v1\./.test(sess), sess);
r = await call('/api/session', { body: { id_token: await idToken({ aud: 'SOMEONE-ELSE' }) } }); ok('session: token for another app refused', r.status === 401);
r = await call('/api/session', { body: { id_token: await idToken({ email_verified: false }) } }); ok('session: unverified email refused', r.status === 401);
r = await call('/api/session', { body: { id_token: await idToken({ exp: 1 }) } }); ok('session: expired token refused', r.status === 401);
const good = await idToken(); r = await call('/api/session', { body: { id_token: good.slice(0, -6) + 'AAAAAA' } }); ok('session: tampered token refused', r.status === 401);
r = await call('/api/session', { body: { id_token: await idToken() }, env: { ...ENV, ALLOWED_EMAILS: 'other@example.com' } }); ok('session: allow-list blocks other Google accounts', r.status === 403);
r = await call('/api/session', { body: { id_token: await idToken() }, env: { ...ENV, ALLOWED_EMAILS: 'SAM@example.com' } }); ok('session: allow-list admits listed account (case-insensitive)', r.status === 200);
r = await call('/api/session', { body: { id_token: await idToken() }, env: { ...ENV, SESSION_SECRET: 'short' } }); ok('session: refuses to run with a weak SESSION_SECRET', r.status === 500);
// chat
const auth = { Authorization: 'Bearer ' + sess };
r = await call('/api/chat', { body: { messages: [{ role: 'user', content: 'hi' }] } }); ok('chat: refused without a session', r.status === 401);
r = await call('/api/chat', { body: { messages: [{ role: 'user', content: 'hi' }] }, headers: { Authorization: 'Bearer v1.AAAA.BBBB' } }); ok('chat: refused with a forged session', r.status === 401);
calls.length = 0;
r = await call('/api/chat', { headers: auth, body: { messages: [{ role: 'system', content: 'Be Jarvis.' }, { role: 'assistant', content: 'old' }, { role: 'user', content: 'Open YouTube' }, { role: 'user', content: 'please' }] } }); t = await text(r);
const up = calls.find(c => c.url.startsWith('https://api.anthropic.com/')), upBody = JSON.parse(up.init.body);
ok('chat: answer returned', r.status === 200 && JSON.parse(t).text === 'Certainly, Sir.', t);
ok('chat: API key sent upstream from the server only', up.init.headers['x-api-key'] === SECRETS.ANTHROPIC_API_KEY && !leaks(t));
ok('chat: system prompt split out, turns merged, starts with user', upBody.system === 'Be Jarvis.' && upBody.messages.length === 1 && upBody.messages[0].role === 'user' && /Open YouTube[\s\S]*please/.test(upBody.messages[0].content), upBody);
r = await call('/api/chat', { headers: auth, body: { messages: 'nope' } }); ok('chat: invalid body rejected', r.status === 400);
r = await call('/api/chat', { headers: auth, body: { messages: Array.from({ length: 41 }, () => ({ role: 'user', content: 'x' })) } }); ok('chat: too many messages rejected', r.status === 400);
r = await call('/api/chat', { headers: auth, raw: JSON.stringify({ messages: [{ role: 'user', content: 'x'.repeat(70000) }] }) }); ok('chat: oversized body rejected', r.status === 413);
r = await call('/api/chat', { headers: auth, body: { messages: [{ role: 'user', content: 'hi' }] }, env: { ...ENV, ANTHROPIC_API_KEY: '', OPENAI_API_KEY: '' } }); ok('chat: not configured -> clear error, no details', r.status === 501 && (await text(r)) === '{"error":"chat_not_configured"}');
// search
r = await call('/api/search', { headers: auth, body: { q: 'jarvis' } }); t = await text(r);
ok('search: results returned, key stays on the server', r.status === 200 && JSON.parse(t).results[0].url === 'https://a.example' && !leaks(t) && calls.some(c => c.url.startsWith('https://api.search.brave.com/') && c.init.headers['X-Subscription-Token'] === SECRETS.BRAVE_API_KEY));
r = await call('/api/search', { headers: auth, body: { q: '  ' } }); ok('search: empty query rejected', r.status === 400);
r = await call('/api/search', { body: { q: 'x' } }); ok('search: refused without a session', r.status === 401);
// google device flow (secret added by the server)
calls.length = 0;
r = await call('/api/google/device/code', { body: { scope: 'https://www.googleapis.com/auth/drive' } }); t = await text(r);
const dcUp = calls.find(c => c.url.endsWith('/device/code'));
ok('device code: scope is fixed server-side and client id returned', r.status === 200 && String(dcUp.init.body).includes('scope=openid+email+profile') && !String(dcUp.init.body).includes('drive') && JSON.parse(t).client_id === 'TVCID', [t, String(dcUp.init.body)]);
calls.length = 0;
r = await call('/api/google/token', { body: { grant_type: 'device_code', device_code: 'DC' } }); t = await text(r);
const tkUp = calls.find(c => c.url.endsWith('/token'));
ok('token: client secret added on the server, never returned', String(tkUp.init.body).includes(encodeURIComponent(SECRETS.GOOGLE_CLIENT_SECRET)) && !leaks(t), t);
ok('token: access token is not passed on, id/refresh tokens are', !t.includes('AT-SHOULD-NOT-LEAK') && JSON.parse(t).id_token === 'IDT' && JSON.parse(t).refresh_token === 'RT1');
r = await call('/api/google/token', { body: { grant_type: 'device_code', device_code: 'PENDING' } }); ok('token: "pending" passes through (428)', r.status === 428 && JSON.parse(await text(r)).error === 'authorization_pending');
calls.length = 0; r = await call('/api/google/token', { body: { grant_type: 'refresh_token', refresh_token: 'RT1' } }); ok('token: refresh grant works', r.status === 200 && String(calls[0].init.body).includes('grant_type=refresh_token'));
r = await call('/api/google/token', { body: { grant_type: 'password', username: 'a' } }); ok('token: other grant types refused', r.status === 400);
r = await call('/api/google/token', { raw: 'grant_type=refresh_token&refresh_token=RT1', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }); ok('token: form-encoded body (native HTTP) accepted', r.status === 200);
// routing and limits
r = await call('/api/nope', { body: {} }); ok('unknown path -> 404', r.status === 404);
r = await call('/api/chat', { method: 'GET' }); ok('wrong method -> 405', r.status === 405);
for (const k of ['x-content-type-options', 'cache-control', 'referrer-policy']) if (!r.headers.get(k)) ok('security header ' + k, false);
ok('security headers present', r.headers.get('x-content-type-options') === 'nosniff' && r.headers.get('cache-control') === 'no-store');
let last = 0; for (let i = 0; i < 31; i++) last = (await call('/api/search', { headers: auth, body: { q: 'rate' } })).status;
ok('rate limit: the 31st request in a minute gets 429', last === 429, last);
const hmac = async (s, p) => { const k = await crypto.subtle.importKey('raw', new TextEncoder().encode(s), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']); return Buffer.from(await crypto.subtle.sign('HMAC', k, new TextEncoder().encode(p))).toString('base64url'); };
const body = e64({ sub: 'zzz', email: 'a@b.c', exp: Math.floor(Date.now() / 1000) - 10 });
r = await call('/api/search', { headers: { Authorization: 'Bearer v1.' + body + '.' + await hmac(ENV.SESSION_SECRET, body) }, body: { q: 'x' } }); ok('an expired (but correctly signed) session is refused', r.status === 401);
console.log(R.join('\n'));
process.exit(/FAIL/.test(R.join('\n')) ? 1 : 0);
