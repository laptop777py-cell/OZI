const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync(require('path').join(__dirname,'..','src','js','00-pure.js'),'utf8');
const ctx={crypto:globalThis.crypto,atob,btoa,TextDecoder,TextEncoder,URL,Date,console};
vm.createContext(ctx);vm.runInContext(src+';this.api={verifyGoogleIdToken,parseModelRef,extractHfModels,pickDtype,needsSearch,classify,parseIntent,learnFacts,matchVoice,stripThink,sentences,isPrivateUrl,rulesReply,fmtGB};',ctx);
const A=ctx.api;let fail=0;const eq=(n,a,b)=>{const x=JSON.stringify(a),y=JSON.stringify(b);if(x!==y){fail++;console.log('FAIL',n,'\n  got ',x,'\n  want',y)}else console.log('ok  ',n)};
// intents
eq('eyes open',A.parseIntent('Open eyes'),{t:'eyes',on:true});
eq('eyes close',A.parseIntent('close your eyes'),{t:'eyes',on:false});
eq('open app',A.parseIntent('open YouTube'),{t:'app',name:'YouTube'});
eq('open url',A.parseIntent('open github.com'),{t:'url',url:'https://github.com'});
eq('timer',A.parseIntent('set a timer for 10 minutes'),{t:'timer',s:600});
eq('alarm',A.parseIntent('set an alarm for 7:30 pm'),{t:'alarm',h:19,m:30});
eq('alarm2',A.parseIntent('wake me up at 6am'),{t:'alarm',h:6,m:0});
eq('call',A.parseIntent('call +1 555 123 4567'),{t:'dial',num:'+15551234567',who:'+1 555 123 4567'});
eq('music',A.parseIntent('play lofi beats on spotify'),{t:'music',q:'lofi beats',app:'spotify'});
eq('email',A.parseIntent('send an email to bob@example.com saying running late'),{t:'email',to:'bob@example.com',body:'running late',subject:'running late'});
eq('sms',A.parseIntent('text 5551234567 saying hi there'),{t:'sms',to:'5551234567',body:'hi there'});
eq('image',A.parseIntent('draw a picture of a neon city at night'),{t:'image',prompt:'a neon city at night'});
eq('imagine',A.parseIntent('imagine a dragon over mountains').t,'image');
eq('add hf',A.parseIntent('add model onnx-community/Qwen3-0.6B-ONNX from hugging face'),{t:'add',ref:{type:'hf',id:'onnx-community/Qwen3-0.6B-ONNX'},raw:'onnx-community/Qwen3-0.6B-ONNX'});
eq('add gh',A.parseIntent('add https://github.com/foo/awesome-free-llms').ref.type,'github');
eq('add search',A.parseIntent('add the qwen coder model from hugging face').t,'add');
eq('not add',A.parseIntent('get me some coffee ideas'),null);
eq('search',A.parseIntent('search best budget phones'),{t:'search',q:'best budget phones'});
eq('yt',A.parseIntent('youtube guitar lessons'),{t:'yt',q:'guitar lessons'});
eq('home',A.parseIntent('turn off the living room light'),{t:'home',on:false,name:'living room light'});
eq('build',A.parseIntent('/build').t,'cmd');eq('build2',A.parseIntent('build ozi ai'),{t:'build'});
eq('remember',A.parseIntent('remember that my wifi is blue'),{t:'remember',text:'my wifi is blue'});
eq('chat none',A.parseIntent('tell me a joke'),null);
eq('status',A.parseIntent('status report'),{t:'status'});
eq('brief',A.parseIntent('Good morning Wixu'),{t:'brief'});
eq('brief2',A.parseIntent('brief me'),{t:'brief'});
eq('convo off',A.parseIntent("that's all"),{t:'convo',on:false});
eq('convo on',A.parseIntent('conversation mode'),{t:'convo',on:true});
eq('remind in',A.parseIntent('remind me in 10 minutes to call mum'),{t:'remind',in:600,text:'call mum'});
eq('remind in 2',A.parseIntent('remind me to take the pills in 2 hours'),{t:'remind',in:7200,text:'take the pills'});
eq('remind at',A.parseIntent('remind me at 7:30 pm to cook dinner'),{t:'remind',h:19,m:30,text:'cook dinner'});
eq('remind at 2',A.parseIntent('remind me to call Sam at 9 am'),{t:'remind',h:9,m:0,text:'call Sam'});
eq('reminders',A.parseIntent('what are my reminders'),{t:'reminders'});
eq('good luck is not a briefing',A.parseIntent('good luck with that'),null);
// search/classify
eq('needs search news',A.needsSearch('what is the latest news about spacex'),true);
eq('no search greeting',A.needsSearch('how are you'),false);
eq('no search personal',A.needsSearch('what do you think about yourself and your name'),false);
eq('classify code',A.classify('fix this python bug').kind,'code');
eq('classify visual',A.classify('what is this thing I am holding').visual,true);
// facts
eq('facts',A.learnFacts('My name is Sam and I live in Dallas. I love jazz music.'),[['name','Sam'],['lives in','Dallas'],['likes love','jazz music']]);
// model refs
eq('ref url',A.parseModelRef('https://huggingface.co/onnx-community/gemma-3-1b-it-ONNX/tree/main'),{type:'hf',id:'onnx-community/gemma-3-1b-it-ONNX'});
eq('ref dataset',A.parseModelRef('https://huggingface.co/datasets/a/b').type,'search');
eq('extract',A.extractHfModels('see https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct. and huggingface.co/datasets/x/y and huggingface.co/meta-llama/Llama-3.2-1B)'),['Qwen/Qwen2.5-0.5B-Instruct','meta-llama/Llama-3.2-1B']);
eq('dtype wasm',A.pickDtype([{rfilename:'onnx/model_q4f16.onnx'},{rfilename:'onnx/model_q4.onnx'}],'wasm'),'q4');
eq('dtype gpu',A.pickDtype([{rfilename:'onnx/model_q4f16.onnx'},{rfilename:'onnx/model_q4.onnx'}],'webgpu'),'q4f16');
eq('private',[A.isPrivateUrl('http://192.168.1.2/x'),A.isPrivateUrl('https://example.com')],[true,false]);
eq('think',A.stripThink('<think>x</think>Hi'),'Hi');
eq('voice',A.matchVoice([{name:'Rachel'},{name:'Brittney - Social Media Voice'}],'Brittney').name,'Brittney - Social Media Voice');
// JWT roundtrip with generated RSA key
(async()=>{
  const kp=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
  const jwk=await crypto.subtle.exportKey('jwk',kp.publicKey);jwk.kid='k1';jwk.alg='RS256';
  const enc=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
  const mk=async(p,h={alg:'RS256',kid:'k1'})=>{const s=enc(h)+'.'+enc(p);const sig=Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',kp.privateKey,Buffer.from(s))).toString('base64url');return s+'.'+sig};
  const now=Math.floor(Date.now()/1000),base={iss:'https://accounts.google.com',aud:'CID',sub:'1',email:'a@b.c',email_verified:true,name:'A',exp:now+3600};
  const jw=async()=>({keys:[jwk]});
  const u=await A.verifyGoogleIdToken(await mk(base),'CID',jw);eq('jwt ok',u.email,'a@b.c');
  for(const [n,p] of [['wrong aud',{...base,aud:'X'}],['expired',{...base,exp:now-9999}],['wrong iss',{...base,iss:'https://evil.com'}],['unverified email',{...base,email_verified:false}],['no email',{...base,email:undefined}]]){try{await A.verifyGoogleIdToken(await mk(p),'CID',jw);eq(n,'accepted','rejected')}catch(e){eq(n,'rejected','rejected')}}
  const t=await mk(base);const bad=t.slice(0,-4)+'AAAA';try{await A.verifyGoogleIdToken(bad,'CID',jw);eq('tampered','accepted','rejected')}catch(e){eq('tampered','rejected','rejected')}
  console.log(fail?('FAILURES: '+fail):'ALL PURE TESTS PASSED');
})();
