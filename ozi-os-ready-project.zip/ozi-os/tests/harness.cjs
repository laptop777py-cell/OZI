const fs=require('fs'),vm=require('vm'),path=require('path');
const SRC=path.join(__dirname,'..','src','js');
module.exports=function make(){
  const code=fs.readdirSync(SRC).filter(f=>f.endsWith('.js')).sort().map(f=>fs.readFileSync(path.join(SRC,f),'utf8')).join('\n');
  function el(){const t={style:{},classList:{add(){},remove(){},toggle(){},contains(){return false}},dataset:{},children:[],value:'',textContent:'',innerHTML:'',appendChild(c){this.children.push(c);return c},querySelector(){return el()},querySelectorAll(){return[]},addEventListener(){},getBoundingClientRect(){return{top:0,height:100,width:100}},scrollTo(){},scrollBy(){},focus(){},click(){},getContext(){return null},remove(){},removeChild(){},isConnected:true,scrollHeight:0,scrollTop:0,clientHeight:0,disabled:false};
    return new Proxy(t,{get(o,k){if(k in o)return o[k];return o[k]=function(){return el()}},set(o,k,v){o[k]=v;return true}})}
  const els={},store=new Map(),idb=new Map();
  const fakeIDB={open(){const req={};setTimeout(()=>{const db={createObjectStore(){},transaction(){const t={};t.objectStore=()=>({get(k){const q={};q.result=idb.get(k);setTimeout(()=>q.onsuccess&&q.onsuccess());return q},put(v,k){idb.set(k,v);setTimeout(()=>t.oncomplete&&t.oncomplete())}});return t}};req.result=db;req.onupgradeneeded&&req.onupgradeneeded();req.onsuccess&&req.onsuccess()});return req}};
  const sandbox={console,setTimeout,clearTimeout,setInterval:()=>0,clearInterval(){},atob,btoa,TextEncoder,TextDecoder,URL,Blob,Uint8Array,Float32Array,Promise,Date,Math,JSON,URLSearchParams,performance,
    crypto:globalThis.crypto,isSecureContext:true,innerHeight:800,devicePixelRatio:2,requestAnimationFrame(){return 0},addEventListener(){},matchMedia:()=>({matches:false}),indexedDB:fakeIDB,
    location:{origin:'https://example.github.io',protocol:'https:',href:'https://example.github.io/ozi/app/',reload(){}},
    navigator:{onLine:true,deviceMemory:4,hardwareConcurrency:4,userAgent:'x',platform:'test',getBattery:async()=>({level:.8,charging:false}),mediaDevices:{}},
    localStorage:{getItem:k=>store.has(k)?store.get(k):null,setItem:(k,v)=>store.set(k,String(v)),removeItem:k=>store.delete(k),clear:()=>store.clear()},
    document:{getElementById:id=>els[id]||(els[id]=el()),createElement:()=>el(),createTextNode:()=>el(),addEventListener(){},hidden:false,body:el(),documentElement:el()},
    fetch:async()=>{throw Error('no network in test')},Image:function(){},FileReader:function(){},open(){}};
  sandbox.window=sandbox;vm.createContext(sandbox);
  return{sandbox,store,idb,run:(c,f)=>vm.runInContext(c,sandbox,{filename:f||'t.js'}),load:()=>vm.runInContext(code,sandbox,{filename:'index-script.js'})};
};
