const H=require('./harness.cjs')();const sandbox=H.sandbox;
sandbox.OZI_CONFIG={googleWebClientId:'WEBID',apiBase:'https://api.example.com'};
H.load();
const test=`(async()=>{
const R=[];const ok=(n,c,x)=>R.push((c?'ok   ':'FAIL ')+n+(c?'':' -> '+JSON.stringify(x)));
const wait=async(f,ms)=>{for(let i=0;i<(ms||4000)/20&&!f();i++)await new Promise(r=>setTimeout(r,20))};
const kp=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const jwk=await crypto.subtle.exportKey('jwk',kp.publicKey);jwk.kid='k1';
const e64=o=>btoa(JSON.stringify(o)).replace(/=+$/,'').replace(/\\+/g,'-').replace(/\\//g,'_');
const mk=async p=>{const s=e64({alg:'RS256',kid:'k1'})+'.'+e64(p);const sig=new Uint8Array(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',kp.privateKey,new TextEncoder().encode(s)));let b='';for(const c of sig)b+=String.fromCharCode(c);return s+'.'+btoa(b).replace(/=+$/,'').replace(/\\+/g,'-').replace(/\\//g,'_')};
const now=Math.floor(Date.now()/1000),claims=(sub,aud,extra)=>Object.assign({iss:'https://accounts.google.com',aud:aud||'TVCID',sub,email:'sam@example.com',email_verified:true,name:'Sam',exp:now+3600},extra||{});
netGet=async u=>{if(/oauth2\\/v3\\/certs/.test(u))return JSON.stringify({keys:[jwk]});throw Error('unexpected '+u)};
let polls=0,REFRESH=async()=>({id_token:await mk(claims('42'))}),deny=false;const sent=[];
postForm=async(u,o)=>{sent.push({u,o});
  if(/\\/api\\/google\\/device\\/code$/.test(u))return{device_code:'DC',user_code:'ABCD-EFGH',verification_url:'https://www.google.com/device',interval:0.01,expires_in:600,client_id:'TVCID'};
  if(/\\/api\\/google\\/token$/.test(u)){if(o.grant_type==='device_code'){polls++;if(polls<2)return{error:'authorization_pending'};return{id_token:await mk(claims('42')),refresh_token:'refresh-token-secret-9f3a'}}if(o.grant_type==='refresh_token')return REFRESH(o)}
};
postJSON=async(u,h,b)=>{sent.push({u,h,b});if(/\\/api\\/session$/.test(u)){if(deny)throw Error('403 {"error":"account_not_allowed"}');return{session:'SESSION-TOKEN-secret-71c9'}}return{}};
// ===== Android app (device-code flow through your server) =====
window.Capacitor={isNativePlatform:()=>true,Plugins:{}};
const opened=[];window.open=u=>{opened.push(u);return{}};
const tap=async()=>{await wait(()=>$('gGo').style.display==='',5000);$('gGo').onclick()};
const pA=authenticate();await wait(()=>$('gGo').style.display==='',6000);
ok('app: first screen is one Google button, no form of any kind, no passcode',$('lockT').textContent==='OZI OS'&&$('gGo').style.display===''&&$('gId').style.display==='none'&&/Sign in with Google/.test($('gGo').innerHTML),[$('lockT').textContent,$('gGo').style.display,$('gId').style.display]);
ok('app: privacy line like a normal sign-in screen',/name and email/.test($('lockFine').textContent));
$('gGo').onclick();await wait(()=>$('gCode').textContent==='ABCD-EFGH',6000);
ok('app: tapping the button shows the code and opens Google with it',$('gCode').textContent==='ABCD-EFGH'&&opened.some(u=>/user_code=ABCD-EFGH/.test(u)),opened);
await pA;
ok('app: signed in; session from the server stored',authMode==='device'&&vault.acct&&vault.acct.email==='sam@example.com'&&vault.acct.session==='SESSION-TOKEN-secret-71c9'&&vault.acct.cid==='TVCID',[authMode,vault.acct]);
ok('app: the page only talks to YOUR server for sign-in (no client secret anywhere)',sent.filter(c=>/google/.test(c.u)).every(c=>c.u.startsWith('https://api.example.com/'))&&!JSON.stringify(sent).match(/client_secret|CLIENT_SECRET/),sent.map(c=>c.u));
ok('app: storage is encrypted (account, refresh token, session)',!['sam@example.com','refresh-token-secret-9f3a','SESSION-TOKEN-secret-71c9'].some(v=>JSON.stringify(ls.get('os_vault')).includes(v)));
ok('app: full access after sign-in',full()===true);
let p0=polls;vault=emptyVault();vkey=null;authMode='none';freshLogin=false;hideLock();
await authenticate();
ok('app: relaunch restores the account silently',vault.acct&&vault.acct.email==='sam@example.com'&&polls===p0,[vault.acct,polls,p0]);
await revalidate();ok('app: valid account passes the re-check and renews the session',vault.acct.email==='sam@example.com'&&sent.some(c=>c.o&&c.o.grant_type==='refresh_token'));
REFRESH=async()=>({error:'invalid_grant'});polls=0;freshLogin=false;
const p3=revalidate();await tap();await p3;
ok('app: revoked access forces a new Google sign-in',polls>=2&&freshLogin&&vault.acct.email==='sam@example.com',[polls,freshLogin]);
REFRESH=async()=>({id_token:await mk(claims('99'))});polls=0;freshLogin=false;
const p4=revalidate();await tap();await p4;ok('app: a different account forces sign-in again',polls>=2,polls);
navigator.onLine=false;freshLogin=false;REFRESH=async()=>{throw Error('x')};await revalidate();
ok('app: offline keeps working',vault.acct.email==='sam@example.com');navigator.onLine=true;
const raw=ls.get('os_vault');raw.ct=raw.ct.slice(0,-8)+'AAAAAAAA';ls.set('os_vault',raw);
vault=emptyVault();vkey=null;authMode='none';freshLogin=false;polls=0;hideLock();
const pT=authenticate();await tap();await pT;ok('app: a corrupted vault is rejected and Google sign-in is required again',vault.acct&&polls>=2,[vault.acct,polls]);
// ===== the server refuses this Google account =====
try{localStorage.clear()}catch{}idbWipe&&idbWipe();vault=emptyVault();vkey=null;authMode='none';freshLogin=false;polls=0;deny=true;hideLock();
let signed=false;authenticate().then(()=>{signed=true});await tap();await wait(()=>/not allowed/.test($('lockM').textContent),6000);
ok('server allow-list: a refused Google account is not let in and is told why',/not allowed/.test($('lockM').textContent)&&signed===false,[$('lockM').textContent,signed]);deny=false;
// ===== website (official Google button) =====
delete window.Capacitor;try{localStorage.clear()}catch{}idbWipe&&idbWipe();vault=emptyVault();vkey=null;authMode='none';freshLogin=false;hideLock();
loadScript=async()=>{window.google={accounts:{id:{initialize(o){window.__cb=o.callback},renderButton(){}}}}};
const pW=authenticate();await wait(()=>window.__cb,6000);
ok('web: shows the official Google button first',$('lockT').textContent==='OZI OS'&&$('gBtn').style.display===''&&$('gGo').style.display==='none'&&$('gId').style.display==='none',[$('lockT').textContent,$('gBtn').style.display]);
await window.__cb({credential:await mk(claims('7','OTHER'))});
ok('web: a token for another app is rejected',/Sign-in failed/.test($('lockM').textContent)&&!vault.acct,$('lockM').textContent);
await window.__cb({credential:await mk(claims('7','WEBID',{email_verified:false}))});
ok('web: an unverified Google email is rejected',/not verified/.test($('lockM').textContent)&&!vault.acct,$('lockM').textContent);
await window.__cb({credential:await mk(claims('7','WEBID'))});await pW;
ok('web: verified Google sign-in accepted, server session stored',vault.acct&&vault.acct.email==='sam@example.com'&&vault.acct.refresh===''&&vault.acct.session==='SESSION-TOKEN-secret-71c9',vault.acct);
vault.acct.at=Date.now()-31*864e5;freshLogin=false;window.__cb=null;
const pW2=revalidate();await wait(()=>window.__cb,3000);await window.__cb({credential:await mk(claims('7','WEBID'))});await pW2;
ok('web: sessions older than 30 days ask for Google again',freshLogin&&vault.acct.at>Date.now()-60000,vault.acct);
// ===== first run offline =====
try{localStorage.clear()}catch{}idbWipe&&idbWipe();vault=emptyVault();vkey=null;authMode='none';navigator.onLine=false;hideLock();
authenticate();await wait(()=>/Connect to the internet/.test($('lockM').textContent),6000);
ok('first run offline asks to connect once',/Connect to the internet/.test($('lockM').textContent),$('lockM').textContent);
// ===== not configured: no form, owner setup is hidden =====
navigator.onLine=true;window.OZI_CONFIG={};try{localStorage.clear()}catch{}vault=emptyVault();vkey=null;authMode='none';hideLock();
authenticate();await wait(()=>/not set up/.test($('lockM').textContent),6000);
ok('unconfigured build: explains, shows no input and no Google button',/not set up/.test($('lockM').textContent)&&$('gId').style.display==='none'&&$('gGo').style.display==='none'&&$('gBtn').style.display==='none',[$('lockM').textContent,$('gId').style.display]);
for(let i=0;i<5;i++)$('lockT').onclick();
ok('owner setup appears only after tapping the title 5 times',$('gId').style.display===''&&$('lockT').textContent==='OWNER SETUP',$('lockT').textContent);
$('gId').value='AIzaSyDOESNOTMATTER';
$('gId').value='WEBID2';await $('lockBtn').onclick();
ok('owner setup stores a public value and returns to the Google screen',ls.get('os_gweb')==='WEBID2'&&$('lockT').textContent==='OZI OS',[ls.get('os_gweb'),$('lockT').textContent]);
// ===== a file opened from storage (content://) =====
const keep=location.protocol;location.protocol='content:';vault=emptyVault();authMode='none';hideLock();
let fileDone=false;authenticate().then(()=>{fileDone=true});await wait(()=>/not from a file/.test($('lockM').textContent),3000);
ok('file copy: explains that Google sign-in needs the website or app, offers no way in',/not from a file/.test($('lockM').textContent)&&$('gGo').style.display==='none'&&$('lockAlt').style.display==='none'&&$('lockBtn').style.display==='none',[$('lockM').textContent]);
await new Promise(r=>setTimeout(r,300));ok('file copy: stays locked',fileDone===false);location.protocol=keep;
// ===== web fallbacks (no native layer) =====
navigator.onLine=true;authMode='device';vault=emptyVault();vault.acct={sub:'1',email:'a@b.c'};consent=async()=>'allow';
opened.length=0;location.href='';
const r1=await runIntent({t:'app',name:'YouTube'});ok('web: "open YouTube" opens the site',/Opening/.test(r1)&&opened[0]==='https://www.youtube.com',[r1,opened]);
const r2=await runIntent({t:'app',name:'Some Unknown App'});ok('web: unknown app explained',/Android app/.test(r2),r2);
const r3=await runIntent({t:'timer',s:60});ok('web: timers need the Android app',/Android app/.test(r3),r3);
const r4=await runIntent({t:'music',q:'lofi',app:'youtube music'});ok('web: music search opens',/Opening/.test(r4)&&/music.youtube.com/.test(opened[1]),[r4,opened]);
return R.join('\\n')})()`;
// fake IndexedDB wipe helper for tests
sandbox.idbWipe=()=>H.idb.clear();
H.run(test).then(r=>{console.log(r);process.exit(/FAIL/.test(r)?1:0)}).catch(e=>{console.log('HARNESS ERROR',e&&e.stack||e);process.exit(2)});
setTimeout(()=>{console.log('TIMEOUT');process.exit(3)},120000);
