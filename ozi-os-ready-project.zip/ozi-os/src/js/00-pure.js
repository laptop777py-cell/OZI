/*PURE-START*/
/* Pure helpers (no DOM): intent parsing, routing hints, token verification, model references. Unit-tested in Node. */
const b64u=s=>{s=String(s).replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';return Uint8Array.from(atob(s),c=>c.charCodeAt(0))};
function jwtParts(t){const p=String(t).split('.');if(p.length!==3)throw Error('malformed token');const td=new TextDecoder();return{h:JSON.parse(td.decode(b64u(p[0]))),p:JSON.parse(td.decode(b64u(p[1]))),sig:b64u(p[2]),signed:new TextEncoder().encode(p[0]+'.'+p[1])}}
async function verifyGoogleIdToken(token,clientId,fetchJwks,now){
  now=now||Date.now()/1000;const {h,p,sig,signed}=jwtParts(token);
  if(h.alg!=='RS256')throw Error('unexpected signing algorithm');
  if(p.iss!=='https://accounts.google.com'&&p.iss!=='accounts.google.com')throw Error('wrong issuer');
  if(p.aud!==clientId)throw Error('token was issued for a different app');
  if(!p.email)throw Error('the token has no email address');
  if(p.email_verified!==true&&p.email_verified!=='true')throw Error('the Google email address is not verified');
  if(!(p.exp>now-60))throw Error('token expired');
  const jwks=await fetchJwks(),jwk=((jwks&&jwks.keys)||[]).find(k=>k.kid===h.kid);if(!jwk)throw Error('signing key not found');
  const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);
  if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,sig,signed))throw Error('signature check failed');
  return{sub:p.sub,email:p.email||'',name:p.name||'',picture:p.picture||'',exp:p.exp};
}
const HF_ID=/^[A-Za-z0-9][\w.-]*\/[\w.-]+$/;
function parseModelRef(s){
  s=String(s).trim().replace(/^["'`]+|["'`.,;]+$/g,'');let m;
  m=s.match(/^https?:\/\/(?:www\.)?huggingface\.co\/([\w.-]+\/[\w.-]+)(?:[\/?#].*)?$/i);
  if(m&&!/^(datasets|spaces|models|docs|blog|papers|collections|organizations)\//i.test(m[1]))return{type:'hf',id:m[1]};
  m=s.match(/^https?:\/\/(?:www\.)?github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?(?:\/(?:blob|tree)\/([^\/]+)\/(.+?))?(?:[?#].*)?$/i);
  if(m)return{type:'github',owner:m[1],repo:m[2],ref:m[3]||'HEAD',path:m[4]||'README.md'};
  if(HF_ID.test(s))return{type:'hf',id:s};
  return{type:'search',q:s};
}
function extractHfModels(md){
  const out=[],seen=new Set();
  for(const m of String(md).matchAll(/huggingface\.co\/([\w.-]+\/[\w.-]+)/g)){
    const id=m[1].replace(/[.]+$/,'');
    if(/^(datasets|spaces|docs|blog|papers|collections|organizations|models)\//i.test(id)||seen.has(id))continue;seen.add(id);out.push(id);
  }
  return out;
}
/* choose the best ONNX precision from a Hub file list, for wasm or webgpu */
function pickDtype(files,device){
  const has=n=>files.some(f=>f.rfilename&&f.rfilename.endsWith('onnx/'+n));
  const order=device==='webgpu'?[['model_q4f16.onnx','q4f16'],['model_q4.onnx','q4'],['model_fp16.onnx','fp16'],['model_quantized.onnx','q8'],['model.onnx','fp32']]:[['model_q4.onnx','q4'],['model_quantized.onnx','q8'],['model_q4f16.onnx','q4f16'],['model_fp16.onnx','fp16'],['model.onnx','fp32']];
  for(const [f,d] of order)if(has(f))return d;return null;
}
const fmtGB=b=>b>=1e9?(b/1e9).toFixed(1)+' GB':Math.max(1,Math.round(b/1e6))+' MB';

function needsSearch(s){
  s=s.toLowerCase();
  if(/^(hi|hello|hey|thanks|thank you|ok|okay|good (morning|evening|night|afternoon)|how are you|who are you|what('s| is) your name)\b/.test(s))return false;
  if(/\b(search|look up|google|find out|latest|news|today|tonight|tomorrow|yesterday|current|currently|right now|price of|how much (is|are|does)|weather|forecast|score|schedule|release date|who won|who is|who was|when is|when did|where is|near me|open now|stock|exchange rate|trending|top \d+)\b/.test(s))return true;
  return /^(who|what|when|where|which|how (many|much|old|tall|far|long))\b/.test(s)&&s.split(/\s+/).length>=4&&!/\b(you|your|yourself|ozi|wixu|wiu)\b/.test(s);
}
function classify(t){
  const s=t.toLowerCase();
  const p={
    image:/\b(draw|paint|generate|create|make|imagine|render)\b.{0,30}\b(image|picture|photo|illustration|logo|wallpaper|art|painting|drawing)\b/.test(s),
    code:/```|\b(code|function|bug|debug|regex|python|javascript|typescript|java|c\+\+|sql|html|css|api|script|compile)\b/.test(s),
    reason:/\b(why|prove|explain|step by step|calculate|solve|derive|analy[sz]e|compare|pros and cons|strategy|plan)\b/.test(s)||s.split(/\s+/).length>40,
    visual:/\b(see|look|watch|show|read|describe|identify|colou?r|holding|wearing|this|that|these|those|here|doing)\b/.test(s)&&/\b(what|which|who|how|is|are|can you|tell me|read|describe)\b/.test(s),
    search:needsSearch(t)
  };
  p.kind=p.image?'image':p.code?'code':p.reason?'reason':'chat';return p;
}
function parseIntent(raw){
  const t=String(raw).trim().replace(/[.!?]+$/,''),s=t.toLowerCase();let m;
  if(t[0]==='/'){const [c,...a]=t.slice(1).split(/\s+/);return{t:'cmd',c:c.toLowerCase(),args:a.join(' ')}}
  if(/^(?:please\s+)?(?:open|turn on|start|activate|wake)\s+(?:your\s+|the\s+|my\s+)?(?:eyes|camera|vision)$/.test(s)||/^(?:look at this|watch me|see me)$/.test(s))return{t:'eyes',on:true};
  if(/^(?:please\s+)?(?:close|turn off|stop|shut|deactivate)\s+(?:your\s+|the\s+|my\s+)?(?:eyes|camera|vision)$/.test(s))return{t:'eyes',on:false};
  if(/^build(?:\s+ozi)?(?:\s+ai)?(?:\s+with\s+ai)?$/.test(s))return{t:'build'};
  if(/^(?:give me a |run a |show (?:me )?(?:a |the )?)?(?:status report|system status|diagnostics|system report)$/.test(s))return{t:'status'};
  if(/^(?:good (?:morning|afternoon|evening)|brief me|(?:daily |morning )?briefing|what'?s (?:up|new) today|update me)(?:\s+\w+)?$/.test(s))return{t:'brief'};
  if(/^(?:stop listening|that'?s all|goodbye|bye|end conversation|stop conversation)(?:\s+\w+)?$/.test(s))return{t:'convo',on:false};
  if(/^(?:start conversation|conversation mode|keep listening|let'?s talk)$/.test(s))return{t:'convo',on:true};
  if(/^(?:what are |show |list )?(?:my )?reminders$/.test(s))return{t:'reminders'};
  const unit=u=>u[0]==='h'?3600:u[0]==='m'?60:1;
  if(m=t.match(/^remind me (?:in|after) (\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\s+(?:to|that|about)\s+(.+)$/i))return{t:'remind',in:Math.round(+m[1]*unit(m[2].toLowerCase())),text:m[3]};
  if(m=t.match(/^remind me (?:to|that|about)\s+(.+?)\s+(?:in|after)\s+(\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)$/i))return{t:'remind',in:Math.round(+m[2]*unit(m[3].toLowerCase())),text:m[1]};
  if(m=t.match(/^remind me at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?\s+(?:to|that|about)\s+(.+)$/i)){let h=+m[1];const mi=+(m[2]||0),ap=(m[3]||'').toLowerCase().replace(/\./g,'');if(ap==='pm'&&h<12)h+=12;if(ap==='am'&&h===12)h=0;if(h<24&&mi<60)return{t:'remind',h,m:mi,text:m[4]}}
  if(m=t.match(/^remind me (?:to|that|about)\s+(.+?)\s+at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)$/i)){let h=+m[2];const mi=+(m[3]||0),ap=m[4].toLowerCase().replace(/\./g,'');if(ap==='pm'&&h<12)h+=12;if(ap==='am'&&h===12)h=0;if(h<24&&mi<60)return{t:'remind',h,m:mi,text:m[1]}}
  if(m=t.match(/^(?:remember|note)\s+(?:that\s+)?(.+)$/i))return{t:'remember',text:m[1]};
  if(m=t.match(/^forget\s+(?:about\s+)?(.+)$/i))return{t:'forget',key:m[1]};
  if(m=t.match(/^(?:add|install|download|get)\s+(?:the\s+|a\s+)?(?:(?:ai\s+)?model\s+)?(.+?)(?:\s+(?:from|on|via)\s+(?:hugging\s?face|github|hf))?$/i)){
    const body=m[1],mentions=/\b(model|hugging\s?face|github|hf)\b/i.test(t),r=parseModelRef(body);
    if(r.type!=='search'||mentions)return{t:'add',ref:r,raw:body};
  }
  if(m=t.match(/^(?:read|summari[sz]e|open)\s+(?:this\s+)?(?:page|link|url|site)?:?\s*(https?:\/\/\S+)$/i))return{t:'read',url:m[1]};
  if(/^(?:please\s+)?(?:draw|paint|generate|create|make|imagine|render|show me)\b/.test(s)&&/\b(image|picture|photo|illustration|logo|wallpaper|art|painting|drawing)\b/.test(s)||/^imagine\b/.test(s))
    return{t:'image',prompt:t.replace(/^(?:please\s+)?(?:draw|paint|generate|create|make|imagine|render|show me)\s+(?:me\s+)?(?:an?\s+|the\s+)?(?:image|picture|photo|illustration|drawing|painting)?\s*(?:of|about|showing)?\s*/i,'')||t};
  if(m=s.match(/^(?:set|create|start)\s+(?:an?\s+)?timer\s+(?:for\s+)?(\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)$/)){const n=+m[1],u=m[2][0];return{t:'timer',s:Math.round(u==='h'?n*3600:u==='m'?n*60:n)}}
  if(m=s.match(/^(?:set|create)\b.*?\balarm\b.*?\b(?:for|at)\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?$/)||s.match(/^wake me(?: up)? at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?$/)){
    let h=+m[1];const mi=+(m[2]||0),ap=(m[3]||'').replace(/\./g,'');if(ap==='pm'&&h<12)h+=12;if(ap==='am'&&h===12)h=0;if(h<24&&mi<60)return{t:'alarm',h,m:mi};
  }
  if(m=t.match(/^(?:call|dial|phone)\s+(.+)$/i))return{t:'dial',num:m[1].replace(/[^\d+*#]/g,''),who:m[1]};
  if(m=t.match(/^(?:send|write|compose|draft)\s+(?:an?\s+)?e-?mail\s+to\s+(\S+@\S+?)(?:\s+(?:saying|about|with subject|subject)\s*:?\s*(.+))?$/i))return{t:'email',to:m[1],body:m[2]||'',subject:(m[2]||'').slice(0,60)};
  if(m=t.match(/^(?:send|text|message)\s+(?:an?\s+)?(?:text|sms|message)?\s*(?:to\s+)?(\+?\d[\d\s-]{5,}\d)\s*(?:saying|that|:)\s*(.+)$/i))return{t:'sms',to:m[1].replace(/[^\d+]/g,''),body:m[2]};
  if(m=t.match(/^(?:play|put on|listen to)\s+(.+?)(?:\s+on\s+(youtube music|spotify|youtube))?$/i))return{t:'music',q:m[1],app:(m[2]||'youtube music').toLowerCase()};
  if(m=t.match(/^(?:turn|switch)\s+(on|off)\s+(?:the\s+|my\s+)?(.+)$/i))return{t:'home',on:m[1].toLowerCase()==='on',name:m[2]};
  if((m=t.match(/^(?:search youtube(?: for)?|youtube|find (?:me )?(?:a )?videos?(?: about| of| on)?)\s+(.+)$/i)))return{t:'yt',q:m[1]};
  if(m=t.match(/^(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+app)?$/i)){
    const name=m[1];if(/^https?:\/\//i.test(name))return{t:'url',url:name};
    if(/^[\w-]+\.(com|org|net|io|ai|app|co|in|dev)\b/i.test(name))return{t:'url',url:'https://'+name};
    return{t:'app',name};
  }
  if(m=t.match(/^(?:search the web for|search for|search|google|look up|find)\s+(.+)$/i))return{t:'search',q:m[1]};
  return null;
}
function learnFacts(text){
  const f=[],add=(k,v)=>{v=String(v).trim().replace(/[.,;!]+$/,'');if(v&&v.length<80)f.push([k,v])};let m;
  if(m=text.match(/\bmy name is ([A-Za-z][\w' -]{1,30}?)(?:[.,!?]|$| and )/i))add('name',m[1]);
  if(m=text.match(/\bcall me ([A-Za-z][\w' -]{1,30}?)(?:[.,!?]|$| and )/i))add('nickname',m[1]);
  if(m=text.match(/\bi (?:live|am living|stay) in ([\w ,'-]{2,40})/i))add('lives in',m[1]);
  if(m=text.match(/\bi work (?:as|at) ([^.!?\n]{2,50})/i))add('work',m[1]);
  if(m=text.match(/\bmy (birthday|favou?rite [\w ]{2,20}|job|school|college|team|hobby|hobbies) is ([^.!?\n]{1,60})/i))add(m[1].toLowerCase(),m[2]);
  if(m=text.match(/\bi (like|love|prefer|enjoy|hate|dislike) ([^.!?\n]{2,50})/i))add('likes '+m[1].toLowerCase(),m[2]);
  return f;
}
function matchVoice(list,name){const n=name.toLowerCase();return(list||[]).find(v=>(v.name||'').toLowerCase()===n)||(list||[]).find(v=>(v.name||'').toLowerCase().split(/[\s\-–—]/)[0]===n)||null}
function stripThink(t){return String(t).replace(/<think>[\s\S]*?(<\/think>|$)/g,'').trim()}
const sentences=t=>(String(t).match(/[^.!?;\n]+[.!?;]*\s*/g)||[String(t)]).map(s=>s.trim()).filter(Boolean);
const cleanMd=s=>(s||'').replace(/!\[[^\]]*\]\([^)]*\)/g,'').replace(/\[([^\]]*)\]\([^)]*\)/g,'$1').replace(/[#*_`>\\]/g,'').replace(/\s+/g,' ').trim().slice(0,320);
const isPrivateUrl=u=>{try{const h=new URL(u).hostname;return /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|0\.|\[?::1)/.test(h)||h.endsWith('.local')||h.endsWith('.internal')}catch{return true}};
/* rule-based fallback when no model is available (no WebGPU/WASM model, offline, or limited mode) */
function rulesReply(text,d){
  const s=text.toLowerCase().trim();
  if(/^(hi|hello|hey|yo|good (morning|afternoon|evening))\b/.test(s))return'Hello. Ozi OS is online. I am running in basic mode, so ask me for time, battery, network, or give a command such as "open YouTube", "set a timer for 5 minutes" or "remember that ...". Download an on-device model in the menu for full conversation.';
  if(/\b(time|clock)\b/.test(s)&&/\bwhat|tell|current|now\b/.test(s))return'It is '+new Date().toLocaleTimeString()+'.';
  if(/\b(date|day)\b/.test(s)&&/\bwhat|today|tell\b/.test(s))return'Today is '+new Date().toDateString()+'.';
  if(/battery/.test(s))return d&&d.battery!=null?`Battery is at ${d.battery}%${d.charging?' and charging':''}.`:'I cannot read the battery on this device.';
  if(/\b(network|wifi|wi-fi|internet|online)\b/.test(s))return d?(d.online?`You are online (${d.netType}).`:'You are offline.'):'Unknown network status.';
  if(/\b(who are you|your name)\b/.test(s))return'I am the Ozi OS assistant, powered by Ozi AI.';
  if(/\b(thanks|thank you)\b/.test(s))return'You are welcome.';
  if(/\bhelp\b|what can you do/.test(s))return'I can search the web (with your permission), see through your camera on "open eyes", open apps, set alarms and timers, draft emails and texts, play music, generate images, remember things, and speak back. Type /help for the full list.';
  return'I am in basic mode: no language model is loaded and no free cloud route is available right now. Open the ° menu and download an on-device model once, then I can answer anything offline.';
}
/*PURE-END*/
