/* ===== network helpers (native HTTP in the Android app: no CORS limits) ===== */
const UA='Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';
const httpPlugin=()=>native()?NP('CapacitorHttp'):undefined;
const withTimeout=(p,ms,label)=>Promise.race([p,new Promise((_,r)=>setTimeout(()=>r(Error((label||'request')+' timed out')),ms))]);
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function netGet(url,headers){
  const http=httpPlugin();
  if(http){const r=await http.request({url,method:'GET',headers:Object.assign({'User-Agent':UA,'Accept-Language':'en-US,en;q=0.9'},headers||{}),responseType:'text'});if(r.status>=400)throw Error('HTTP '+r.status);return typeof r.data==='string'?r.data:JSON.stringify(r.data)}
  const r=await fetch(url,headers?{headers}:undefined);if(!r.ok)throw Error('HTTP '+r.status);return r.text()
}
async function postJSON(url,headers,body){
  const http=httpPlugin();
  if(http){const r=await http.request({url,method:'POST',headers:Object.assign({'Content-Type':'application/json'},headers||{}),data:body,responseType:'json'});if(r.status>=400)throw Error(r.status+' '+JSON.stringify(r.data).slice(0,160));return r.data}
  const r=await fetch(url,{method:'POST',headers:Object.assign({'content-type':'application/json'},headers||{}),body:JSON.stringify(body)});
  if(!r.ok)throw Error(r.status+' '+(await r.text()).slice(0,160));return r.json()
}
async function postForm(url,obj){
  const http=httpPlugin();
  if(http){const r=await http.request({url,method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},data:obj,responseType:'json'});return typeof r.data==='string'?JSON.parse(r.data):r.data}
  const r=await fetch(url,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams(obj)});return r.json()
}

/* ===== permission prompts (asked every single time) ===== */
function consent({title,why,allow='Allow once',alt,deny='Deny'}){
  return new Promise(res=>{
    $('cTitle').textContent=title;$('cWhy').textContent=why;$('cB1').textContent=allow;
    $('cB2').style.display=alt?'':'none';if(alt)$('cB2').textContent=alt;$('cB3').textContent=deny;
    const el=$('consent');el.classList.add('show');const done=v=>{el.classList.remove('show');res(v)};
    $('cB1').onclick=()=>done('allow');$('cB2').onclick=()=>done('alt');$('cB3').onclick=()=>done('deny');
  })
}
const full=()=>!!vault.acct;
const LIMITED_MSG='Sign in with Google to unlock internet, camera and phone control.';
const permOf=k=>((vault.cfg.perm||{})[k]);
function setPerm(k,v){(vault.cfg.perm||(vault.cfg.perm={}))[k]=v;persist();if(typeof fillPerms==='function')fillPerms()}
/* Internet: asked ONCE ("Always allow"), changeable any time in the ° menu. Downloads, search, cloud models and voices all follow it. */
async function needNet(desc){
  if(!full()||turn.offlineOnly||!net())return false;
  if(turn.allowed)return true;
  const p=permOf('net');
  if(p==='always'){turn.allowed=true;return true}
  if(p==='off'){turn.offlineOnly=true;return false}
  const r=await consent({title:'ALLOW INTERNET ACCESS?',why:`Ozi OS uses the internet to ${desc}, and also to ask free cloud AI models, search the web, download AI models and speak with online voices. Nothing goes to any Ozi server. You are asked once; change it any time in the ° menu → Permissions.`,allow:'Always allow',alt:'Just this time',deny:'Stay offline'});
  if(r==='allow'){setPerm('net','always');turn.allowed=true;return true}
  if(r==='alt'){turn.allowed=true;return true}
  turn.offlineOnly=true;return false;
}
async function needAction(title,why,kind){
  if(!full())return LIMITED_MSG;
  kind=kind||'phone';if(permOf(kind)==='always')return null;
  const r=await consent({title,why,allow:'Allow once',alt:'Always allow',deny:'Not now'});
  if(r==='allow')return null;
  if(r==='alt'){setPerm(kind,'always');return null}
  return'Understood. I did not do it.';
}

/* ===== internet data: Google/DuckDuckGo/YouTube/Wikipedia pages read on this device ===== */
/* Search through your own Ozi server (keeps the search API key on the server). Returns [] when no server is configured. */
async function proxySearch(q){
  if(!apiBase()||!(vault.acct&&vault.acct.session))return[];
  try{const j=await withTimeout(apiCall('/api/search',{q}),15000,'Ozi server');return(j.results||[]).map(x=>({title:x.title,url:x.url,snippet:cleanMd(x.snippet)}))}
  catch(e){log('server search: '+(e.message||e));return[]}
}
async function googleScrape(q){
  const doc=new DOMParser().parseFromString(await netGet('https://www.google.com/search?hl=en&num=8&q='+encodeURIComponent(q)),'text/html'),out=[],seen=new Set();
  doc.querySelectorAll('a[href^="/url?q="],a[href^="https://www.google.com/url?q="]').forEach(a=>{
    const m=a.getAttribute('href').match(/[?&]q=([^&]+)/);if(!m)return;let u;try{u=decodeURIComponent(m[1])}catch{return}
    if(!/^https?:/.test(u)||/google\.[a-z.]+\//.test(u)||seen.has(u))return;
    const title=((a.querySelector('h3,div[role="heading"]')||a).textContent||'').trim();if(!title)return;seen.add(u);
    const box=a.closest('div.g,div.ZINbbc,div.Gx5Zad,div.egMi0')||a.parentElement,sn=box&&box.textContent?box.textContent.replace(title,'').trim().slice(0,200):'';
    out.push({title:title.slice(0,120),url:u,snippet:sn});
  });
  if(out.length<2)throw Error('Google returned no readable results');return out.slice(0,6);
}
async function ddg(q){
  const doc=new DOMParser().parseFromString(await netGet('https://html.duckduckgo.com/html/?q='+encodeURIComponent(q)),'text/html');
  const out=[...doc.querySelectorAll('.result:not(.result--ad)')].slice(0,6).map(r=>{const a=r.querySelector('a.result__a');if(!a)return null;let u=a.getAttribute('href')||'';const m=u.match(/[?&]uddg=([^&]+)/);if(m)u=decodeURIComponent(m[1]);if(u.startsWith('//'))u='https:'+u;const sn=r.querySelector('.result__snippet');return{title:a.textContent.trim(),url:u,snippet:sn?sn.textContent.trim():''}}).filter(x=>x&&/^https?:/.test(x.url));
  if(!out.length)throw Error('DuckDuckGo returned no results');return out;
}
async function wiki(q){
  const j=JSON.parse(await netGet('https://en.wikipedia.org/w/api.php?action=query&list=search&format=json&origin=*&srlimit=5&srsearch='+encodeURIComponent(q)));
  return(j.query&&j.query.search||[]).map(s=>({title:s.title,url:'https://en.wikipedia.org/wiki/'+encodeURIComponent(s.title.replace(/ /g,'_')),snippet:s.snippet.replace(/<[^>]+>/g,'')}));
}
async function ytScrape(q){
  const html=await netGet('https://www.youtube.com/results?hl=en&search_query='+encodeURIComponent(q)),m=html.match(/var ytInitialData = (\{[\s\S]*?\});<\/script>/);if(!m)throw Error('no YouTube data');
  const out=[];(function walk(o){if(!o||typeof o!=='object'||out.length>=6)return;if(o.videoRenderer){const v=o.videoRenderer;out.push({title:(v.title&&v.title.runs&&v.title.runs[0].text)||'video',snippet:[v.ownerText&&v.ownerText.runs&&v.ownerText.runs[0].text,v.lengthText&&v.lengthText.simpleText,v.viewCountText&&v.viewCountText.simpleText].filter(Boolean).join(' · '),url:'https://www.youtube.com/watch?v='+v.videoId});return}for(const k in o)walk(o[k])})(JSON.parse(m[1]));
  if(!out.length)throw Error('no videos found');return out;
}
async function webSearch(q){
  try{
    const px=await proxySearch(q);if(px.length)return{source:'Ozi search server',results:px};
    for(const [name,fn] of [['Google',googleScrape],['DuckDuckGo',ddg]]){try{const r=await withTimeout(fn(q),12000,name);if(r.length)return{source:name,results:r}}catch(e){log('search '+name+': '+e.message)}}
    return{source:'Wikipedia',results:await withTimeout(wiki(q),10000,'Wikipedia')};
  }catch(e){return{results:[],note:e.message||String(e)}}
}
async function ytSearch(q){
  try{
    const px=await proxySearch('site:youtube.com '+q);if(px.length)return{source:'YouTube via Ozi search server',results:px};
    try{return{source:'YouTube',results:await withTimeout(ytScrape(q),12000,'YouTube')}}catch(e){log('youtube: '+e.message);return{source:'YouTube via DuckDuckGo',results:await withTimeout(ddg('site:youtube.com '+q),12000,'DuckDuckGo')}}
  }catch(e){return{results:[],note:e.message||String(e)}}
}
async function readPage(url){
  if(isPrivateUrl(url))return{ok:false,note:'Local and private network addresses are not allowed.'};
  try{const doc=new DOMParser().parseFromString(await withTimeout(netGet(url),15000,'page'),'text/html');doc.querySelectorAll('script,style,noscript,svg,iframe,nav,footer,header').forEach(n=>n.remove());
    return{ok:true,title:doc.title||url,text:((doc.body&&doc.body.textContent)||'').replace(/\s+/g,' ').trim().slice(0,4500)}}catch(e){return{ok:false,note:e.message+(native()?'':' (browsers block reading other sites; the Android app can)')}}
}
function fmtResults(r,n){return(r.results||[]).slice(0,n||5).map((x,i)=>`[${i+1}] ${x.title}${x.snippet?' — '+x.snippet:''} (${x.url})`).join('\n')}
function noteSources(r){(r.results||[]).slice(0,5).forEach(x=>pendingSrc.push({title:x.title,url:x.url}))}

/* ===== image generation: several free models (Pollinations, no key) + Hugging Face models with a free token ===== */
const IMG_DEFAULT=['flux','turbo'];
const HF_IMAGE=[['black-forest-labs/FLUX.1-schnell','FLUX.1 schnell (fast)'],['black-forest-labs/FLUX.1-dev','FLUX.1 dev (quality)'],['stabilityai/stable-diffusion-xl-base-1.0','Stable Diffusion XL'],['stabilityai/stable-diffusion-3.5-large','Stable Diffusion 3.5 Large']];
function imageChoices(){
  const poll=(vault.cfg.imModels&&vault.cfg.imModels.length?vault.cfg.imModels:IMG_DEFAULT).map(x=>['poll:'+x,'Free, no key · '+x]);
  return poll.concat(HF_IMAGE.map(([id,n])=>['hf:'+id,'Free HF token · '+n]));
}
async function hfImage(prompt,model,tok){
  const r=await withTimeout(fetch('https://router.huggingface.co/hf-inference/models/'+model,{method:'POST',headers:{Authorization:'Bearer '+tok,'Content-Type':'application/json'},body:JSON.stringify({inputs:prompt})}),70000,'Hugging Face image');
  if(r.ok&&/image/.test(r.headers.get('content-type')||''))return URL.createObjectURL(await r.blob());
  throw Error('Hugging Face image HTTP '+r.status);
}
async function pollImage(prompt,model){
  const pk=(vault.cfg.poll||{}).key,seed=Math.floor(Math.random()*1e6),q=encodeURIComponent(prompt);
  const url=pk?`https://gen.pollinations.ai/image/${q}?model=${model}&width=768&height=768&seed=${seed}&nologo=true&key=${encodeURIComponent(pk)}`:`https://image.pollinations.ai/prompt/${q}?model=${model}&width=768&height=768&seed=${seed}&nologo=true&private=true`;
  await new Promise((ok,no)=>{const im=new Image(),t=setTimeout(()=>no(Error('the image service timed out')),70000);im.onload=()=>{clearTimeout(t);ok()};im.onerror=()=>{clearTimeout(t);no(Error('the free image service is unavailable right now'))};im.src=url});
  return url;
}
async function generateImage(prompt){
  const hf=(vault.cfg.hf||{}).token,sel=vault.cfg.imModel||'poll:flux',i=sel.indexOf(':'),kind=i<0?'poll':sel.slice(0,i),model=i<0?sel:sel.slice(i+1),order=[];
  if(kind==='hf'&&hf)order.push(['hf',model]);if(kind==='poll')order.push(['poll',model]);
  if(hf&&!order.some(o=>o[0]==='hf'))order.push(['hf',HF_IMAGE[0][0]]);if(!order.some(o=>o[0]==='poll'))order.push(['poll','flux']);
  let err;for(const [k,m] of order){try{return k==='hf'?await hfImage(prompt,m,hf):await pollImage(prompt,m)}catch(e){err=e;log('image '+k+' '+m+': '+(e.message||e))}}
  throw err;
}

/* ===== authentication: Google account only =====
   Android app: Google device-code sign-in. Website: Google Identity Services button. Both are verified on this device against
   Google's public keys. Data lives in an AES-256-GCM vault whose key is stored non-extractable in this browser/app profile.
   No passcode and no other account exist. */
const enc=new TextEncoder(),dec=new TextDecoder();
let vkey=null,persistT=0;
const emptyVault=()=>({cfg:{},mem:{},chat:[],acct:null,limited:false,models:[],usage:{},reminders:[]});
const b64=u=>{u=new Uint8Array(u);let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
function idbOpen(){return new Promise((ok,no)=>{const r=indexedDB.open('ozi-keys',1);r.onupgradeneeded=()=>r.result.createObjectStore('k');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}
async function deviceKey(){
  const db=await idbOpen(),get=()=>new Promise((ok,no)=>{const q=db.transaction('k').objectStore('k').get('vault');q.onsuccess=()=>ok(q.result);q.onerror=()=>no(q.error)});
  let k=await get();
  if(!k){k=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);await new Promise((ok,no)=>{const t=db.transaction('k','readwrite');t.objectStore('k').put(k,'vault');t.oncomplete=ok;t.onerror=()=>no(t.error)})}
  return k;
}
async function seal(){const iv=crypto.getRandomValues(new Uint8Array(12)),ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},vkey,enc.encode(JSON.stringify(vault)));ls.set('os_vault',{v:2,iv:b64(iv),ct:b64(ct)})}
async function unseal(raw){return JSON.parse(dec.decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(raw.iv)},vkey,unb64(raw.ct))))}
function persist(){clearTimeout(persistT);persistT=setTimeout(doPersist,500)}
async function doPersist(){try{if(authMode==='device'&&vkey)await seal();else ls.set('os_store',vault)}catch(e){log('save failed: '+e.message)}}
const lockEl=$('lock'),lockMsg=t=>{$('lockM').textContent=t||'';$('lockM').style.display=t?'':'none'},hideLock=()=>lockEl.classList.remove('show');
function showLock(o){
  $('lockT').textContent=o.title||'OZI OS';$('lockTag').textContent=o.tag||'';$('lockTag').style.display=o.tag?'':'none';lockMsg(o.msg);
  $('gId').value='';$('gId').style.display=o.gid?'':'none';
  $('gBtn').style.display=o.gbtn?'':'none';$('gGo').style.display=o.gogo?'':'none';
  $('gCode').textContent=o.code||'';$('gCode').style.display=o.code?'':'none';
  $('lockBtn').textContent=o.btn||'Continue';$('lockBtn').style.display=o.btn?'':'none';
  $('lockFine').textContent=o.fine||'';$('lockFine').style.display=o.fine?'':'none';
  $('lockAlt').textContent=o.alt||'';$('lockAlt').style.display=o.alt?'':'none';
  lockEl.classList.add('show');
}
const openExternal=u=>{const np=NP('OziNative');if(native()&&np)return np.openUrl({url:u}).catch(()=>window.open(u,'_blank'));window.open(u,'_blank','noopener')};
/* Public settings only (config.js). The Google client SECRET and every API key live on the server, never here. */
const gClient=()=>{const c=window.OZI_CONFIG||{};return{webId:c.googleWebClientId||ls.get('os_gweb','')||'',api:String(c.apiBase||ls.get('os_api','')||'').replace(/\/+$/,'')}};
const apiBase=()=>gClient().api;
const fetchJwks=async()=>JSON.parse(await netGet('https://www.googleapis.com/oauth2/v3/certs'));
let freshLogin=false;
async function apiCall(path,body){
  const api=apiBase();if(!api)throw Error('no Ozi server configured');
  const s=vault.acct&&vault.acct.session;
  return postJSON(api+path,s?{Authorization:'Bearer '+s}:{},body);
}
/* The server checks the Google ID token again and returns its own signed session (used for chat and search). */
async function registerSession(idToken){
  if(!apiBase())return'';
  try{const j=await withTimeout(postJSON(apiBase()+'/api/session',{},{id_token:idToken}),12000,'Ozi server');return j.session||''}
  catch(e){if(/403/.test(String(e.message)))throw Error('This Google account is not allowed to use this server.');log('session: '+e.message);return''}
}
const TAG='One secure Google sign-in and your assistant remembers everything.';
const FINE='We request only your name and email (openid, profile, email). Google verifies your identity on this device; Ozi never sees or stores a password.';
const GLOGO='<svg width="20" height="20" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4.1 7.1-10.1 7.1-17.5z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
$('gGo').innerHTML=GLOGO+'<span>Sign in with Google</span>';
let titleTaps=0,onTitleTap=null;$('lockT').onclick=()=>{if(++titleTaps>=5){titleTaps=0;if(onTitleTap)onTitleTap()}};
function loadScript(src){return new Promise((ok,no)=>{const s=document.createElement('script');s.src=src;s.async=true;s.onload=ok;s.onerror=()=>no(Error('could not load '+src));(document.head||document.documentElement||document.body).appendChild(s)})}
/* Sign-in screen: one button. Website: the official Google button (Google Identity Services). Android app: Google device-code flow
   through your server (the server holds the client secret). Both are verified on the device against Google's public keys. */
function googleLogin(reason){return new Promise(res=>{
  const web=!native()&&/^https?:$/.test(location.protocol);let stop=false,ended=false;
  const done=a=>{if(ended)return;ended=stop=true;freshLogin=true;onTitleTap=null;hideLock();res(a)};
  const note=(msg,btn)=>{showLock({title:'OZI OS',tag:TAG,msg,btn:btn||'Try again'});$('lockBtn').onclick=()=>intro()};
  /* hidden owner setup (tap the title 5 times): only for builds without a configured public setting */
  onTitleTap=()=>{
    const c=gClient();
    showLock({title:'OWNER SETUP',msg:web?'Paste the public Google "Web application" client ID for this site. Authorized JavaScript origin to add: '+location.origin:'Paste the URL of your Ozi server (README, "Server").',gid:true,btn:'Save',alt:'Back'});
    $('gId').placeholder=web?'Google web client ID':'https://your-ozi-server.example';$('gId').value=web?c.webId:c.api;
    $('lockBtn').onclick=()=>{const v=$('gId').value.trim();if(!v)return lockMsg('Enter a value.');if(web)ls.set('os_gweb',v);else ls.set('os_api',v.replace(/\/+$/,''));intro()};
    $('lockAlt').onclick=()=>intro();
  };
  const webStart=async()=>{
    const id=gClient().webId;
    try{
      await loadScript('https://accounts.google.com/gsi/client');
      showLock({title:'OZI OS',tag:TAG,msg:reason,gbtn:true,fine:FINE});
      google.accounts.id.initialize({client_id:id,ux_mode:'popup',callback:async r=>{if(ended)return;try{const u=await verifyGoogleIdToken(r.credential,id,fetchJwks);const session=await registerSession(r.credential);done({sub:u.sub,email:u.email,name:u.name,refresh:'',cid:id,session,at:Date.now()})}catch(e){lockMsg('Sign-in failed: '+(e.message||e))}}});
      google.accounts.id.renderButton($('gBtn'),{theme:'filled_black',size:'large',shape:'pill',text:'signin_with',logo_alignment:'left',width:300});
    }catch(e){note('Could not reach Google: '+(e.message||e))}
  };
  const deviceStart=async()=>{
    const api=gClient().api;stop=false;
    try{
      const dc=await postForm(api+'/api/google/device/code',{scope:'openid email profile'});
      if(!dc||dc.error||!dc.device_code)throw Error((dc&&(dc.error_description||dc.error))||'Google did not return a device code');
      const vurl=(dc.verification_url||dc.verification_uri||'https://www.google.com/device')+'?user_code='+encodeURIComponent(dc.user_code);
      try{await navigator.clipboard.writeText(dc.user_code)}catch(e){}
      showLock({title:'APPROVE ON GOOGLE',msg:'Your code is copied and Google is opening in your browser. Paste the code, then approve with your Google account. This screen continues by itself.',code:dc.user_code,btn:'Open Google again',alt:'Cancel'});
      $('lockBtn').onclick=()=>openExternal(vurl);$('lockAlt').onclick=()=>{stop=true;intro()};openExternal(vurl);
      let wait=(dc.interval||5)*1000;const until=Date.now()+(dc.expires_in||1800)*1000;
      while(!stop&&Date.now()<until){
        await sleep(wait);if(stop)return;
        const t=await postForm(api+'/api/google/token',{grant_type:'device_code',device_code:dc.device_code});
        if(t&&t.id_token){const u=await verifyGoogleIdToken(t.id_token,dc.client_id,fetchJwks),session=await registerSession(t.id_token);done({sub:u.sub,email:u.email,name:u.name,refresh:t.refresh_token||'',cid:dc.client_id,session,at:Date.now()});return}
        if(t&&t.error==='authorization_pending')continue;
        if(t&&t.error==='slow_down'){wait+=5000;continue}
        throw Error((t&&(t.error_description||t.error))||'sign-in failed');
      }
      if(!stop)throw Error('The code expired. Try again.');
    }catch(e){if(!stop){stop=true;note(String(e.message||e))}}
  };
  const intro=()=>{
    stop=false;const c=gClient();
    if(web?!c.webId:!c.api){note('Google sign-in is not set up in this build yet. The owner adds the public settings once in config.js (README, "Configure").');return}
    if(!net()){note('Connect to the internet to sign in with Google. After that Ozi OS also works offline.','Retry');return}
    if(web)webStart();else{showLock({title:'OZI OS',tag:TAG,msg:reason,gogo:true,fine:FINE});$('gGo').onclick=()=>deviceStart()}
  };
  intro();
})}
/* every start: confirm the Google account is still authorised (app) or the session is recent (website); offline use is allowed */
async function revalidate(){
  const a=vault.acct,c=gClient(),again=async why=>{vault.acct=null;vault.acct=await googleLogin(why);await doPersist();secInfo()};
  if(!a)return again('Sign in with Google to continue.');
  if(freshLogin)return;
  if(!a.refresh){if(Date.now()-(a.at||0)>30*864e5)return again('Your Google session expired. Please sign in again.');return}
  if(!net()||!c.api)return;
  showLock({title:'CHECKING YOUR GOOGLE ACCOUNT',msg:'One moment…'});
  try{
    const t=await withTimeout(postForm(c.api+'/api/google/token',{grant_type:'refresh_token',refresh_token:a.refresh}),8000,'Google');
    if(t&&t.error==='invalid_grant'){hideLock();return again('Your Google sign-in is no longer valid. Please sign in again.')}
    if(t&&t.id_token){const u=await verifyGoogleIdToken(t.id_token,a.cid,fetchJwks);if(u.sub!==a.sub){hideLock();return again('A different Google account was detected. Please sign in again.')}const s=await registerSession(t.id_token);if(s)a.session=s}
    a.at=Date.now();persist();
  }catch(e){if(/not allowed/.test(String(e.message))){hideLock();return again(e.message)}log('google re-check skipped: '+(e.message||e))}
  hideLock();
}
const localFile=()=>!native()&&!/^https?:$/.test(location.protocol);
/* No way in without a real Google account. */
function gate(msg){return new Promise(()=>{showLock({title:'OZI OS',tag:TAG,msg,fine:FINE})})}
async function authenticate(){
  if(localFile())return gate('Google sign-in works only from the Ozi OS website address or the Android app, not from a file stored on your phone. Open the website address or install the app.');
  if(window.crypto&&crypto.subtle&&window.indexedDB){
    authMode='device';try{vkey=await deviceKey()}catch(e){log('device key unavailable: '+e.message);vkey=null}
    if(vkey){
      const raw=ls.get('os_vault',null);
      if(raw){try{vault=Object.assign(emptyVault(),await unseal(raw))}catch(e){log('saved data could not be opened: '+e.message);vault=emptyVault()}}
      if(!vault.acct){vault.acct=await googleLogin();await doPersist()}
      return;
    }
  }
  authMode='plain';vault=Object.assign(vault,ls.get('os_store',{}));if(!vault.acct){vault.acct=await googleLogin();await doPersist()}
}
function loadConfig(){return new Promise(res=>{const s=document.createElement('script');s.src='config.js';s.onload=s.onerror=()=>res();(document.head||document.documentElement||document.body).appendChild(s);setTimeout(res,2500)})}

/* ===== on-device engine client (Web Worker: Transformers.js + Kokoro) ===== */
const Eng={w:null,n:0,p:new Map(),caps:null,dead:false,llmId:null,llmName:'',asr:null,tts:false,cap:false,cached:new Set(),
  start(){if(this.dead)return false;if(this.w)return true;try{this.w=new Worker('engine-worker.js',{type:'module'});this.w.onmessage=e=>this.msg(e.data);this.w.onerror=ev=>{log('engine worker: '+(ev.message||'could not start'));if(!this.caps)this.dead=true;this.fail(Error('engine unavailable'))};return true}catch(e){this.dead=true;return false}},
  msg(m){const p=this.p.get(m.id);if(!p)return;if(m.progress&&p.onp)p.onp(m.progress);if(m.token!=null&&p.onTok)p.onTok(m.token);if(m.error){this.p.delete(m.id);p.rej(Error(m.error))}else if(m.done){this.p.delete(m.id);p.res(m)}},
  fail(e){for(const[,p]of this.p)p.rej(e);this.p.clear()},
  call(type,pl,o){o=o||{};if(!this.start())return Promise.reject(Error('On-device engine is available in the Android app'));return new Promise((res,rej)=>{const id=++this.n;this.p.set(id,{res,rej,onp:o.onp,onTok:o.onTok});this.w.postMessage(Object.assign({id,type},pl||{}),o.transfer||[])})},
  async probe(){if(this.caps)return this.caps;if(!this.start())return null;try{this.caps=await withTimeout(this.call('caps'),9000,'engine');const c=await this.call('cached');this.cached=new Set(c.ids||[])}catch(e){this.dead=true;this.caps=null;log('engine: '+e.message)}return this.caps}};
let LASTROUTE='';

/* ===== model library ===== */
const CURATED=[
 {id:'qwen25-05b',name:'Qwen2.5 0.5B Instruct',kind:'llm',hf:'onnx-community/Qwen2.5-0.5B-Instruct',dtype:{webgpu:'q4',wasm:'q4'},gb:.5,note:'Fast. Good for phones.'},
 {id:'qwen3-06b',name:'Qwen3 0.6B',kind:'llm',hf:'onnx-community/Qwen3-0.6B-ONNX',dtype:{webgpu:'q4f16',wasm:'q4'},gb:.6,note:'Newer, better reasoning.'},
 {id:'smollm2-360m',name:'SmolLM2 360M Instruct',kind:'llm',hf:'onnx-community/SmolLM2-360M-Instruct',dtype:{webgpu:'q4',wasm:'q4'},gb:.3,note:'Tiny. For weak phones.'},
 {id:'llama32-1b',name:'Llama 3.2 1B Instruct',kind:'llm',hf:'onnx-community/Llama-3.2-1B-Instruct-ONNX',dtype:{webgpu:'q4f16',wasm:'q4'},gb:.95,note:'Balanced quality.'},
 {id:'gemma3-1b',name:'Gemma 3 1B (newer than Gemma 2 2B)',kind:'llm',hf:'onnx-community/gemma-3-1b-it-ONNX',dtype:{webgpu:'q4',wasm:'q4'},gb:.85,note:'Google. Good chat quality.'},
 {id:'qwen25-15b',name:'Qwen2.5 1.5B Instruct',kind:'llm',hf:'onnx-community/Qwen2.5-1.5B-Instruct',dtype:{webgpu:'q4',wasm:'q4'},gb:1.2,note:'Needs about 6 GB RAM.'},
 {id:'phi35',name:'Phi-3.5 mini',kind:'llm',hf:'onnx-community/Phi-3.5-mini-instruct-onnx-web',dtype:{webgpu:'q4f16',wasm:'q4f16'},gb:2.3,gpuOnly:true,note:'Laptops with WebGPU only.'},
 {id:'whisper-tiny',name:'Whisper tiny (offline voice typing)',kind:'asr',hf:'onnx-community/whisper-tiny.en',gb:.08,note:'English.'},
 {id:'whisper-base',name:'Whisper base (more accurate)',kind:'asr',hf:'onnx-community/whisper-base',gb:.2,note:'Multilingual.'},
 {id:'kokoro',name:'Kokoro 82M (offline voices)',kind:'tts',hf:'onnx-community/Kokoro-82M-v1.0-ONNX',gb:.1,note:'Natural offline speech.'},
 {id:'vision',name:'ViT-GPT2 captioner (offline eyes)',kind:'cap',hf:'Xenova/vit-gpt2-image-captioning',gb:.35,note:'Describes camera frames offline.'}
];
const MODELS=()=>CURATED.concat(vault.models||[]);
const MS={};
function recommendModel(dev,caps){const ram=dev.ramGB||4,gpu=caps?caps.webgpu:dev.webgpu;if(ram<=3)return'smollm2-360m';if(ram<=4)return'qwen25-05b';if(gpu&&ram>=8)return'llama32-1b';return gpu?'gemma3-1b':'qwen25-05b'}
function modelState(m){const s=MS[m.id];if(s&&s.state==='downloading')return'downloading';if(m.kind==='llm'&&Eng.llmId===m.id)return'loaded';if(m.kind==='asr'&&Eng.asr===m.id)return'loaded';if(m.kind==='tts'&&Eng.tts)return'loaded';if(m.kind==='cap'&&Eng.cap)return'loaded';return Eng.cached.has(m.hf)?'cached':'none'}
function renderModels(){
  const box=$('mlist');box.innerHTML='';
  const rec=recommendModel({ramGB:navigator.deviceMemory,webgpu:!!navigator.gpu},Eng.caps);
  MODELS().forEach(m=>{
    const st=modelState(m),row=document.createElement('div');row.className='mrow'+(st==='loaded'?' act':'');row.dataset.id=m.id;
    const pct=(MS[m.id]&&MS[m.id].pct)||0;
    row.innerHTML='<b></b><span></span><div class="bar"><i style="width:'+pct+'%"></i></div><div class="chips"></div>';
    row.querySelector('b').textContent=m.name+(m.id===rec?'  ★ recommended':'');
    row.querySelector('span').textContent=(m.kind==='cloud'?'cloud-only':'≈'+m.gb+' GB')+' · '+m.note+' · '+({loaded:'loaded',cached:'downloaded',downloading:'downloading '+pct+'%',none:'not downloaded'})[st]+((MS[m.id]&&MS[m.id].err)?' · '+MS[m.id].err:'');
    const ch=row.querySelector('.chips'),btn=(label,a)=>{const b=document.createElement('button');b.className='chip';b.textContent=label;b.dataset.a=a;b.dataset.id=m.id;ch.appendChild(b)};
    if(m.kind==='cloud')btn('Remove','del');
    else{if(st==='none')btn('Download','dl');if(st==='cached'||st==='loaded'){btn(st==='loaded'?'Loaded':'Use','use');btn('Delete','del')}}
    if(m.id.startsWith('hf:')&&m.kind!=='cloud')btn('Remove','rm');
    box.appendChild(row);
  });
}
$('mlist').onclick=e=>{const b=e.target.closest('button[data-a]');if(!b)return;const id=b.dataset.id;if(b.dataset.a==='dl'||b.dataset.a==='use')downloadModel(id);else if(b.dataset.a==='del')deleteModel(id);else if(b.dataset.a==='rm'){vault.models=vault.models.filter(x=>x.id!==id);persist();renderModels()}};
async function downloadModel(id){
  const m=MODELS().find(x=>x.id===id);if(!m)return;
  if(m.kind==='cloud')return;
  if(!full())return sys(LIMITED_MSG);
  if(!(await Eng.probe()))return sys('On-device models need a browser or app with WebAssembly support. The engine could not start here.');
  const dev=Eng.caps.webgpu?'webgpu':'wasm';
  if(m.gpuOnly&&dev!=='webgpu')return sys(m.name+' needs WebGPU, which this device does not have. Try Qwen2.5 0.5B or Gemma 3 1B.');
  if(!Eng.cached.has(m.hf)){
    if(!net())return sys('Downloading needs the internet once. You are offline.');
    turn.allowed=false;turn.offlineOnly=false;
    if(!(await needNet('download '+m.name+' (about '+m.gb+' GB) from Hugging Face. It is saved on this device and works offline afterwards')))return sys('Downloading needs internet permission. Turn it on in the ° menu → Permissions.');
  }
  MS[id]={state:'downloading',pct:0};renderModels();const agg=new Map(),prev=state;
  const onp=p=>{if(p.file)agg.set(p.file,{l:p.loaded||0,t:p.total||0});let L=0,T=0;agg.forEach(v=>{L+=v.l;T+=v.t});const pct=T?Math.min(99,Math.round(L/T*100)):0;if(pct!==MS[id].pct){MS[id].pct=pct;const row=$('mlist').querySelector('.mrow[data-id="'+id+'"]');if(row){row.querySelector('.bar i').style.width=pct+'%';row.querySelector('span').textContent='downloading '+pct+'%'}$('st').textContent='DOWNLOADING '+pct+'%'}};
  try{
    const dtype=(m.dtype&&(m.dtype[dev]||m.dtype.wasm))||undefined;
    if(m.kind==='llm'){await Eng.call('load-llm',{hf:m.hf,dtype,device:dev,dtypeWasm:(m.dtype&&m.dtype.wasm)||'q4'},{onp});Eng.llmId=id;Eng.llmName=m.name}
    else if(m.kind==='asr'){await Eng.call('load-asr',{hf:m.hf,device:dev},{onp});Eng.asr=id}
    else if(m.kind==='tts'){await Eng.call('load-tts',{hf:m.hf},{onp});Eng.tts=true}
    else if(m.kind==='cap'){await Eng.call('load-cap',{hf:m.hf,device:dev},{onp});Eng.cap=true}
    Eng.cached.add(m.hf);MS[id]={state:'ready'};log('model ready: '+m.name+' ('+dev+')');sys(m.name+' is ready'+(m.kind==='llm'?' and active. It is saved on this device, so you only download it once.':'.'));
  }catch(e){MS[id]={state:'idle',err:String(e.message||e).slice(0,80)};sys('Could not load '+m.name+': '+(e.message||e)+(dev==='wasm'?'':' (WebGPU failed; try again to use the CPU path)'))}
  renderModels();setState(prev);
}
async function deleteModel(id){
  const m=MODELS().find(x=>x.id===id);if(!m)return;
  try{await Eng.call('purge',{hf:m.hf,kind:m.kind});}catch(e){return sys('Could not delete: '+e.message)}
  if(Eng.llmId===id){Eng.llmId=null;Eng.llmName=''}if(Eng.asr===id)Eng.asr=null;if(m.kind==='tts')Eng.tts=false;if(m.kind==='cap')Eng.cap=false;
  Eng.cached.delete(m.hf);MS[id]={state:'idle'};renderModels();sys(m.name+' deleted from this device.');
}

/* ===== add any Hugging Face / GitHub model by typing or saying it ===== */
const DT_FILE={q4:'model_q4.onnx',q4f16:'model_q4f16.onnx',q8:'model_quantized.onnx',fp16:'model_fp16.onnx',fp32:'model.onnx'};
async function addHf(id){
  if(MODELS().some(m=>m.hf===id))return id+' is already in your library.';
  if(!(await needNet('look up '+id+' on Hugging Face')))return'I need internet permission to look up a model.';
  let j;try{j=JSON.parse(await withTimeout(netGet('https://huggingface.co/api/models/'+id+'?blobs=true'),15000,'Hugging Face'))}catch(e){return'I could not find '+id+' on Hugging Face ('+e.message+').'}
  const files=j.siblings||[],tag=j.pipeline_tag,kind=({'text-generation':'llm','automatic-speech-recognition':'asr','image-to-text':'cap'})[tag];
  const dw=pickDtype(files,'wasm'),dg=pickDtype(files,'webgpu'),short=id.split('/')[1];
  if(kind&&dw){
    const f=DT_FILE[dw],bytes=files.filter(x=>x.rfilename.startsWith('onnx/'+f)).reduce((a,x)=>a+(x.size||0),0);
    const entry={id:'hf:'+id,name:short,kind,hf:id,dtype:{wasm:dw,webgpu:dg||dw},gb:+(bytes/1e9).toFixed(2)||.5,note:'Added from Hugging Face'+(tag?' ('+tag+')':'')};
    vault.models.push(entry);persist();renderModels();
    sysButtons(`Added ${short} (${fmtGB(bytes)}, ${dw}). It is not downloaded yet.`,[{label:'Download now',fn:()=>downloadModel(entry.id)}]);
    return`${short} is in your model library. Download it once and it works offline.`;
  }
  if((vault.cfg.hf||{}).token&&tag==='text-generation'){vault.models.push({id:'hf:'+id,name:short,kind:'cloud',hf:id,note:'Runs via Hugging Face cloud (your free token)'});persist();renderModels();return`${short} has no browser-ready ONNX files, so I added it as a cloud model that runs through your Hugging Face token.`}
  return`${id} cannot run on this device (${tag||'unknown type'}${kind?'':', not a type Ozi can run'}${dw?'':', no ONNX weights'}). Add a free Hugging Face token in the menu to use text models from the cloud.`;
}
async function addFromGithub(r){
  if(!(await needNet('read the model list at github.com/'+r.owner+'/'+r.repo)))return'I need internet permission to read that list.';
  let md;try{md=await withTimeout(netGet(`https://raw.githubusercontent.com/${r.owner}/${r.repo}/${r.ref}/${r.path}`),15000,'GitHub')}catch(e){return'I could not read that GitHub page ('+e.message+').'}
  const ids=extractHfModels(md).slice(0,12);if(!ids.length)return'I found no Hugging Face models in that list.';
  sysButtons(`Found ${ids.length} models in ${r.owner}/${r.repo}. Tap one to add it:`,ids.map(id=>({label:id.split('/')[1].slice(0,26),fn:async()=>{const t=await addHf(id);sys(t)}})));
  return'Pick a model from the list above.';
}
async function addFromSearch(q){
  if(!(await needNet('search Hugging Face for "'+q+'"')))return'I need internet permission to search models.';
  try{const j=JSON.parse(await withTimeout(netGet('https://huggingface.co/api/models?filter=transformers.js&sort=downloads&limit=6&search='+encodeURIComponent(q)),15000,'Hugging Face'));
    if(!j.length)return'No browser-ready models found for "'+q+'". Paste an exact Hugging Face ID or URL.';
    sysButtons('Browser-ready models for "'+q+'". Tap one to add it:',j.map(x=>({label:x.id.split('/')[1].slice(0,26),fn:async()=>{const t=await addHf(x.id);sys(t)}})));return'Pick a model from the list above.';
  }catch(e){return'Search failed: '+e.message}
}
async function addModelFlow(ref){return ref.type==='hf'?addHf(ref.id):ref.type==='github'?addFromGithub(ref):addFromSearch(ref.q)}
