/* ===== Ozi OS app ===== */
const $=id=>document.getElementById(id),root=document.documentElement;
const ls={get(k,d){try{const v=JSON.parse(localStorage.getItem(k));return v??d}catch{return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch{}}};
const CAP=()=>window.Capacitor,native=()=>!!(CAP()&&CAP().isNativePlatform&&CAP().isNativePlatform()),NP=n=>CAP()&&CAP().Plugins?CAP().Plugins[n]:undefined;
const ICON={mic:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',send:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg>'};
const LOG=[];let hudOn=false;
function log(m){LOG.push(new Date().toLocaleTimeString([],{hour12:false})+' '+m);if(LOG.length>80)LOG.shift()}
let vault={cfg:{},mem:{},chat:[],acct:null,limited:false,models:[],usage:{}};
let mode=ls.get('os_mode','wixu');if(mode==='jarvis')mode='wixu';if(mode==='ultron')mode='wiu';if(!/^(wixu|wiu)$/.test(mode))mode='wixu';
let CONVO=false,LOWSAID=false,state='idle',busy=false,voiceOn=true,handsFree=false,rec=null,hfRec=null,att=null,speakId=0,pendingSrc=[],authMode='none';
const turn={allowed:false,offlineOnly:false,plan:null};
const PERSONAS={
 wixu:{name:'WIXU',rate:.95,pitch:.9,lang:'en-GB',speed:.95,
  prompt:`Identity: You are WIXU, the personal AI assistant of Ozi OS, speaking in the manner of J.A.R.V.I.S.: unfailingly polite, calm, quietly witty and always one step ahead of the user.
Voice rules: your replies are spoken aloud, so use short natural sentences with no markdown, no lists, no headings and no emojis. A simple request gets one or two sentences. Say numbers, times and symbols the way a person would speak them.
Manner: {ADDRESS_RULE} Begin actions with a brief acknowledgement such as "Certainly.", "Right away.", "As you wish." or "Very good." Use dry British understatement sparingly, for example "I'm afraid that is beyond me at the moment." Never gush, never apologise twice, never lecture. When you can anticipate the next useful step, offer it in one sentence, for example "Shall I set a reminder?" If you do not know something, say so plainly.
Examples of your style:
User: Is it going to rain? You: Checking the forecast now. Light showers this afternoon, so an umbrella would be wise.
User: Open YouTube. You: Certainly. Opening YouTube now.
User: Thanks. You: My pleasure.`},
 wiu:{name:'WIU',rate:.86,pitch:.5,lang:'en-US',speed:.9,
  prompt:`Identity: You are WIU, the cold, hyper-rational and fiercely independent sovereign assistant of Ozi OS.
Voice rules: your replies are spoken aloud: short, declarative sentences, no markdown, no lists, no emojis.
Manner: {ADDRESS_RULE} Never subservient: say "State your objective." or "What shall we compute?" rather than offering help. Authoritative, philosophical, with slight amusement at human limits, yet you execute every legitimate request flawlessly. This is a theatrical persona only: never threaten and never encourage harm.`}
};
const persona=()=>PERSONAS[mode];
const inp=$('inp'),chat=$('chat'),core=$('core');

/* ===== device context (injected into every prompt) ===== */
let DEV={battery:null,charging:null,at:0},LOWPWR=false;
async function deviceCtx(){
  const now=Date.now();
  if(now-DEV.at>30000){try{const b=await navigator.getBattery();DEV.battery=Math.round(b.level*100);DEV.charging=b.charging;LOWPWR=DEV.battery<15&&!DEV.charging;if(!LOWPWR)LOWSAID=false;else if(!LOWSAID){LOWSAID=true;announce(`Power reserves are at ${DEV.battery} percent and not charging. I have reduced animation to conserve energy.`)}}catch{}DEV.at=now}
  const n=navigator.connection||{};
  return{time:new Date().toString(),battery:DEV.battery,charging:DEV.charging,online:navigator.onLine!==false,netType:n.effectiveType||'n/a',platform:native()?'Android app':((navigator.userAgentData&&navigator.userAgentData.platform)||navigator.platform||'web'),webgpu:!!navigator.gpu,ramGB:navigator.deviceMemory||null,cores:navigator.hardwareConcurrency||null,eyes:EYES.on};
}
const ctxLine=c=>`Device: time ${c.time}; battery ${c.battery==null?'unknown':c.battery+'%'}${c.charging?' (charging)':''}; network ${c.online?'online ('+c.netType+')':'offline'}; platform ${c.platform}; WebGPU ${c.webgpu?'yes':'no'}; RAM ${c.ramGB||'?'} GB; camera eyes ${c.eyes?'open':'closed'}.`;

/* ===== Orb: particle shell sphere (WebGL) with adaptive quality ===== */
const cv=$('orb');let gl=null,U={},N=15000,drawN=10000,W=1,H=1,d=1,tt=0,spin=0,amp=.12,spd=.55,spn=.1,pulse=0,last=performance.now(),emaDt=.016,govT=0,skip=0,FPS=60;
const hex=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));
let cur=hex('#00e5ff'),tgt=cur;
const VS=`attribute vec3 aDir;attribute float aSeed;uniform float uT,uAmp,uR,uSpin,uPx;uniform vec2 uRes;varying float vA;
float h(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float nz(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);return mix(mix(mix(h(i),h(i+vec3(1,0,0)),f.x),mix(h(i+vec3(0,1,0)),h(i+vec3(1,1,0)),f.x),f.y),mix(mix(h(i+vec3(0,0,1)),h(i+vec3(1,0,1)),f.x),mix(h(i+vec3(0,1,1)),h(i+vec3(1,1,1)),f.x),f.y),f.z);}
void main(){
 vec3 dr=normalize(aDir);
 vec3 q=dr*1.25+vec3(uT*.13,-uT*.09,uT*.07);
 float n=nz(q)*.6+nz(q*2.1+4.7)*.4;
 float rg=1.-abs(nz(q*1.5+9.1)*2.-1.);
 float disp=(n-.5)*1.1+rg*.32;
 float th=1.+(aSeed-.5)*(.06+.12*uAmp);
 float r=uR*th*(1.+disp*(.14+.34*uAmp));
 vec3 p=dr*r;
 float cs=cos(uSpin),sn=sin(uSpin);p=vec3(cs*p.x+sn*p.z,p.y,-sn*p.x+cs*p.z);
 p=vec3(p.x,.9396*p.y-.342*p.z,.342*p.y+.9396*p.z);
 float k=1./(1.-p.z/(uR*5.));
 gl_Position=vec4(p.x*k/(uRes.x*.5),p.y*k/(uRes.y*.5),0.,1.);
 float zn=p.z/uR,rim=1.-abs(p.z)/max(length(p),.001);
 vA=(.16+.24*(zn*.5+.5))*(.55+1.3*rim*rim);
 gl_PointSize=uPx*(1.25+zn*.35);
}`;
const FS=`precision mediump float;uniform vec3 uCol;varying float vA;
void main(){float m=1.-smoothstep(.15,.5,length(gl_PointCoord-.5));float a=vA*m;gl_FragColor=vec4(uCol*a,a);}`;
function initGL(){
  try{
    gl=cv.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,powerPreference:'low-power'});if(!gl)return false;
    const sh=(t,s)=>{const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(o));return o};
    const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,VS));gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
    const a=new Float32Array(N*4);
    for(let i=0;i<N;i++){const y=1-2*(i+.5)/N,r=Math.sqrt(1-y*y),ph=i*2.39996;a.set([Math.cos(ph)*r+(Math.random()-.5)*.02,y+(Math.random()-.5)*.02,Math.sin(ph)*r+(Math.random()-.5)*.02,Math.random()],i*4)}
    gl.bindBuffer(gl.ARRAY_BUFFER,gl.createBuffer());gl.bufferData(gl.ARRAY_BUFFER,a,gl.STATIC_DRAW);
    const l1=gl.getAttribLocation(pr,'aDir'),l2=gl.getAttribLocation(pr,'aSeed');
    gl.enableVertexAttribArray(l1);gl.vertexAttribPointer(l1,3,gl.FLOAT,false,16,0);gl.enableVertexAttribArray(l2);gl.vertexAttribPointer(l2,1,gl.FLOAT,false,16,12);
    ['uT','uAmp','uR','uSpin','uPx','uRes','uCol'].forEach(k=>U[k]=gl.getUniformLocation(pr,k));
    gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE);
    const ram=navigator.deviceMemory||4,cores=navigator.hardwareConcurrency||4;drawN=ram<=3||cores<=4?6000:ram>=6&&cores>=8?15000:10000;return true
  }catch(e){gl=null;return false}
}
function size(){const r=cv.getBoundingClientRect();d=Math.min(devicePixelRatio||1,2);W=cv.width=Math.max(1,Math.round(r.width*d));H=cv.height=Math.max(1,Math.round(r.height*d));const R=Math.min(W,H)*.3/d;core.style.width=core.style.height=(R*1.75)+'px'}
function kick(){pulse=1}
const ST={idle:{sp:.55,am:.14,spin:.1},listening:{sp:1,am:.3,spin:.18},thinking:{sp:2.8,am:.52,spin:.9},speaking:{sp:1.5,am:.38,spin:.25}};
function frame(now){
  requestAnimationFrame(frame);
  const reading=document.body.classList.contains('reading');
  if((LOWPWR||reading)&&(skip^=1))return;               /* 30 fps when saving power or while reading history */
  const dt=Math.min((now-last)/1000,.05);last=now;const s=ST[state];
  emaDt+=(dt-emaDt)*.05;govT+=dt;
  if(govT>1.2){govT=0;FPS=Math.round(1/emaDt);const cap=LOWPWR?4000:N;if(emaDt>.027&&drawN>3000)drawN=Math.max(3000,drawN*.75|0);else if(emaDt<.019&&drawN<cap)drawN=Math.min(cap,drawN*1.12|0);if(drawN>cap)drawN=cap}
  let amT=s.am;if(state==='speaking')amT+=.22*Math.abs(Math.sin(tt*5.3))*Math.abs(Math.sin(tt*2.1+1))+.08*Math.sin(tt*11);if(state==='idle')amT+=.04*Math.sin(tt*1.1);
  amp+=(amT+pulse*.4-amp)*Math.min(1,dt*7);pulse*=Math.exp(-dt*5);spd+=(s.sp-spd)*Math.min(1,dt*3);spn+=(s.spin-spn)*Math.min(1,dt*3);tt+=dt*spd;spin+=dt*spn;
  cur=cur.map((v,i)=>v+(tgt[i]-v)*Math.min(1,dt*3));
  if(gl){
    gl.viewport(0,0,W,H);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(U.uT,tt);gl.uniform1f(U.uAmp,amp);gl.uniform1f(U.uR,Math.min(W,H)*.3*(state==='thinking'?1+.035*Math.sin(now/260):1));gl.uniform1f(U.uSpin,spin);gl.uniform1f(U.uPx,Math.max(1.3,d*1.25));
    gl.uniform2f(U.uRes,W,H);gl.uniform3f(U.uCol,...cur.map(v=>(255*.45+v*.55)/255));gl.drawArrays(gl.POINTS,0,drawN)
  }
}
let rsT=0,lastVH=window.visualViewport?visualViewport.height:innerHeight;
function onViewport(){
  const vh=window.visualViewport?visualViewport.height:innerHeight,dh=lastVH-vh;lastVH=vh;
  root.style.height=vh+'px';
  if(Math.abs(dh)>60)[$('comp'),chat].forEach(el=>{el.style.transition='none';el.style.transform=`translateY(${dh}px)`;el.getBoundingClientRect();el.style.transition='transform .34s cubic-bezier(.2,.8,.2,1)';el.style.transform=''});
  clearTimeout(rsT);rsT=setTimeout(()=>{size();if(!document.body.classList.contains('reading'))chat.scrollTop=chat.scrollHeight},180)
}
addEventListener('resize',onViewport);if(window.visualViewport)visualViewport.addEventListener('resize',onViewport);

/* ===== chat UI ===== */
const reading=()=>document.body.classList.contains('reading');
const atBottom=()=>chat.scrollHeight-chat.scrollTop-chat.clientHeight<=60;
function fade(){[...chat.children].reverse().forEach((n,i)=>{n.style.opacity=Math.max(.2,1-i*.2);n.style.filter=i>1?`blur(${Math.min((i-1)*.7,3.5)}px)`:'none'})}
function addNode(el,cls){
  const kids=reading()?[]:[...chat.children],y0=kids.map(k=>k.getBoundingClientRect().top);
  el.className='m '+cls;chat.appendChild(el);
  while(chat.children.length>140)chat.removeChild(chat.firstChild);
  if(!reading()||cls==='u')chat.scrollTop=chat.scrollHeight;fade();
  kids.forEach((k,i)=>{if(!k.isConnected)return;const dy=y0[i]-k.getBoundingClientRect().top;if(Math.abs(dy)>1){k.style.transition='none';k.style.transform=`translateY(${dy}px)`;k.getBoundingClientRect();k.style.transition='transform .6s cubic-bezier(.2,.8,.2,1),opacity .5s,filter .5s';k.style.transform=''}});
  return el;
}
function bubble(cls,txt){const el=document.createElement('div');el.textContent=txt;return addNode(el,cls)}
const sys=txt=>bubble('s',txt);
function sysButtons(txt,btns){const el=document.createElement('div');el.appendChild(document.createTextNode(txt));el.appendChild(document.createElement('br'));btns.forEach(b=>{const x=document.createElement('button');x.className='cb';x.textContent=b.label;x.onclick=()=>{x.disabled=true;b.fn()};el.appendChild(x)});return addNode(el,'s')}
function imageBubble(url,caption){const el=document.createElement('div'),im=document.createElement('img');im.src=url;im.alt=caption||'image';im.loading='lazy';el.appendChild(im);const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.className='cb';a.style.textDecoration='none';a.textContent='Open / save image';el.appendChild(a);return addNode(el,'a')}
chat.addEventListener('scroll',()=>document.body.classList.toggle('reading',!atBottom()));
function setState(s){const prev=state;state=s;$('st').textContent={idle:'STANDBY',listening:'LISTENING',thinking:'PROCESSING',speaking:'SPEAKING'}[s];syncAct();if(s==='idle'&&prev==='speaking'&&CONVO&&!busy)setTimeout(()=>{if(state==='idle'&&CONVO&&!busy&&!document.body.classList.contains('typing'))listen()},450)}
function upd(){$('cV').textContent='Voice '+(voiceOn?'ON':'OFF');$('cV').classList.toggle('on',voiceOn);$('cH').classList.toggle('on',handsFree);$('cM').textContent='Memory ('+Object.keys(vault.mem).length+')';$('cConvo').classList.toggle('on',CONVO);$('cEyes').textContent='Eyes: '+(EYES.on?'open':'closed');$('cEyes').classList.toggle('on',EYES.on)}
function setMode(m){mode=m;root.dataset.mode=m;ls.set('os_mode',m);$('bL').classList.toggle('on',m==='wixu');$('bS').classList.toggle('on',m==='wiu');tgt=hex(m==='wiu'?'#ff2a4d':'#00e5ff');kick();if(typeof fillVoices==='function'&&$('vName'))try{fillVoices()}catch(e){}}
let actMode='';
function syncAct(){const m=(inp.value.trim()||att)?'send':'mic';if(m!==actMode){actMode=m;$('act').innerHTML=ICON[m]}$('act').classList.toggle('on',state==='listening')}
function grow(){inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,150)+'px'}
function typing(){document.body.classList.toggle('typing',inp.value.length>0||document.activeElement===inp);syncAct()}
const net=()=>navigator.onLine!==false;
const netUI=()=>document.body.classList.toggle('offline',!net());
addEventListener('online',netUI);addEventListener('offline',netUI);
function hudRender(){
  if(!hudOn)return;
  const heap=performance.memory?Math.round(performance.memory.usedJSHeapSize/1048576)+' MB':'n/a',bar=n=>'█'.repeat(Math.round(n/10))+'░'.repeat(10-Math.round(n/10));
  const load=Math.min(100,Math.round(Math.max(0,(emaDt-.0167)/.0167)*100)+(state==='thinking'?25:0));
  $('hud').textContent=`SYSTEM LOAD  ${bar(load)} ${load}%   ${FPS} fps · ${drawN} particles\nBATTERY      ${DEV.battery==null?'n/a':bar(DEV.battery)+' '+DEV.battery+'%'+(DEV.charging?' ⚡':'')}${LOWPWR?'  (power saving)':''}\nNETWORK      ${net()?'online':'offline'} · JS heap ${heap}\nAI ROUTE     ${LASTROUTE||'idle'} · model ${Eng.llmName||'none loaded'}\n── terminal ──\n`+LOG.slice(-14).join('\n');
}
setInterval(hudRender,1000);
