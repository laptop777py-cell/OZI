package com.ozi.os;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(OziNativePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
