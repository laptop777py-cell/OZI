package com.ozi.os;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.provider.AlarmClock;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.List;
import java.util.Locale;

/** Small native bridge: open installed apps by name, open links / dialer / email / SMS drafts, request alarms and timers. */
@CapacitorPlugin(name = "OziNative")
public class OziNativePlugin extends Plugin {

    @PluginMethod
    public void openApp(PluginCall call) {
        String name = call.getString("name", "");
        name = name == null ? "" : name.toLowerCase(Locale.ROOT).trim();
        if (name.isEmpty()) {
            call.reject("name required");
            return;
        }
        PackageManager pm = getContext().getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
        ResolveInfo best = null;
        int bestScore = 0;
        for (ResolveInfo ri : apps) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            int score = label.equals(name) ? 3 : (label.startsWith(name) ? 2 : (label.contains(name) ? 1 : 0));
            if (score > bestScore) {
                bestScore = score;
                best = ri;
            }
        }
        JSObject out = new JSObject();
        if (best == null) {
            out.put("opened", false);
            out.put("reason", "No installed app matches \"" + name + "\"");
            call.resolve(out);
            return;
        }
        Intent launch = pm.getLaunchIntentForPackage(best.activityInfo.packageName);
        if (launch == null) {
            call.reject("App cannot be launched");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            getContext().startActivity(launch);
            out.put("opened", true);
            out.put("app", best.loadLabel(pm).toString());
            call.resolve(out);
        } catch (Exception e) {
            call.reject("Could not open app: " + e.getMessage());
        }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        String url = call.getString("url", "");
        if (url == null) url = "";
        String lower = url.toLowerCase(Locale.ROOT);
        if (!(lower.startsWith("https://") || lower.startsWith("http://") || lower.startsWith("tel:") || lower.startsWith("mailto:") || lower.startsWith("sms:") || lower.startsWith("smsto:"))) {
            call.reject("Only http, https, tel, mailto and sms links are allowed");
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open link: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setAlarm(PluginCall call) {
        Integer hour = call.getInt("hour");
        Integer minute = call.getInt("minute", 0);
        if (hour == null || hour < 0 || hour > 23 || minute == null || minute < 0 || minute > 59) {
            call.reject("hour (0-23) and minute (0-59) required");
            return;
        }
        try {
            Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
            i.putExtra(AlarmClock.EXTRA_HOUR, hour.intValue());
            i.putExtra(AlarmClock.EXTRA_MINUTES, minute.intValue());
            i.putExtra(AlarmClock.EXTRA_MESSAGE, call.getString("label", "OmniOS"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open the clock app: " + e.getMessage());
        }
    }

    @PluginMethod
    public void setTimer(PluginCall call) {
        Integer seconds = call.getInt("seconds");
        if (seconds == null || seconds < 1) {
            call.reject("seconds required");
            return;
        }
        try {
            Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
            i.putExtra(AlarmClock.EXTRA_LENGTH, seconds.intValue());
            i.putExtra(AlarmClock.EXTRA_MESSAGE, call.getString("label", "OmniOS"));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Could not open the clock app: " + e.getMessage());
        }
    }
}
