/* Ozi OS on-device engine (runs in a Web Worker so the interface never freezes).
   Transformers.js (ONNX Runtime Web: WebGPU when present, else WASM) + Kokoro TTS. */
import { pipeline, TextStreamer, env, InterruptableStoppingCriteria } from '@huggingface/transformers';
import { KokoroTTS } from 'kokoro-js';

env.allowLocalModels = false;
env.useBrowserCache = true;                       // models are cached once, then reused offline
const ORT_DEFAULT = env.backends.onnx.wasm.wasmPaths;
const ORT_LOCAL = new URL('./vendor/ort/', self.location.href).href;
let ortMode = 'local';
try { env.backends.onnx.wasm.wasmPaths = ORT_LOCAL; } catch (e) {}

const S = { llm: null, llmId: null, asr: null, asrId: null, tts: null, cap: null, stop: null };
const post = (m, t) => self.postMessage(m, t || []);
const hasGPU = async () => { try { if (self.navigator && navigator.gpu) return !!(await navigator.gpu.requestAdapter()); } catch (e) {} return false; };
const prog = id => p => {
  if (p && (p.status === 'progress' || p.status === 'initiate' || p.status === 'download' || p.status === 'done'))
    post({ id, progress: { status: p.status, file: p.file, loaded: p.loaded, total: p.total } });
};
/* if the bundled WASM files cannot be loaded, retry once with the default CDN location */
async function withOrt(fn) {
  try { return await fn(); }
  catch (e) {
    if (ortMode === 'local' && /wasm|mjs|import|fetch|ort|backend|load/i.test(String((e && e.message) || e))) {
      ortMode = 'cdn'; try { env.backends.onnx.wasm.wasmPaths = ORT_DEFAULT; } catch (x) {}
      return await fn();
    }
    throw e;
  }
}
async function unloadLLM() { try { if (S.llm && S.llm.dispose) await S.llm.dispose(); } catch (e) {} S.llm = null; S.llmId = null; }

self.onmessage = async e => {
  const m = e.data, id = m.id;
  try {
    switch (m.type) {
      case 'caps':
        post({ id, done: true, webgpu: await hasGPU(), cores: navigator.hardwareConcurrency || null, mem: navigator.deviceMemory || null });
        break;
      case 'cached': {
        const c = await caches.open(env.cacheKey || 'transformers-cache'), ks = await c.keys(), ids = new Set();
        for (const r of ks) { const mm = r.url.match(/huggingface\.co\/([^/]+\/[^/]+)\//); if (mm) ids.add(mm[1]); }
        post({ id, done: true, ids: [...ids] });
        break;
      }
      case 'purge': {
        const c = await caches.open(env.cacheKey || 'transformers-cache'), ks = await c.keys();
        for (const r of ks) if (r.url.includes('/' + m.hf + '/')) await c.delete(r);
        if (S.llmId === m.hf) await unloadLLM();
        if (S.asrId === m.hf) { S.asr = null; S.asrId = null; }
        if (m.kind === 'tts') S.tts = null;
        if (m.kind === 'cap') S.cap = null;
        post({ id, done: true });
        break;
      }
      case 'load-llm': {
        await unloadLLM();
        try {
          S.llm = await withOrt(() => pipeline('text-generation', m.hf, { dtype: m.dtype, device: m.device, progress_callback: prog(id) }));
        } catch (err) {
          if (m.device !== 'webgpu') throw err;       // WebGPU failed: fall back to the CPU (WASM) path
          S.llm = await withOrt(() => pipeline('text-generation', m.hf, { dtype: m.dtypeWasm || 'q4', device: 'wasm', progress_callback: prog(id) }));
        }
        S.llmId = m.hf; post({ id, done: true });
        break;
      }
      case 'gen': {
        if (!S.llm) throw new Error('no model loaded');
        S.stop = new InterruptableStoppingCriteria();
        const streamer = new TextStreamer(S.llm.tokenizer, { skip_prompt: true, skip_special_tokens: true, callback_function: t => post({ id, token: t }) });
        const out = await S.llm(m.messages, { max_new_tokens: m.max || 320, do_sample: true, temperature: 0.7, top_p: 0.9, repetition_penalty: 1.05, streamer, stopping_criteria: S.stop });
        const g = out[0].generated_text;
        post({ id, done: true, text: Array.isArray(g) ? g[g.length - 1].content : String(g) });
        break;
      }
      case 'stop': if (S.stop) S.stop.interrupt(); post({ id, done: true }); break;
      case 'load-asr':
        S.asr = await withOrt(() => pipeline('automatic-speech-recognition', m.hf, { device: m.device === 'webgpu' ? 'webgpu' : 'wasm', progress_callback: prog(id) }));
        S.asrId = m.hf; post({ id, done: true });
        break;
      case 'asr': {
        if (!S.asr) throw new Error('no speech model loaded');
        const r = await S.asr(m.audio, { chunk_length_s: 30 });
        post({ id, done: true, text: Array.isArray(r) ? r.map(x => x.text).join(' ') : r.text });
        break;
      }
      case 'load-tts':
        S.tts = await withOrt(() => KokoroTTS.from_pretrained(m.hf, { dtype: 'q8', device: 'wasm', progress_callback: prog(id) }));
        post({ id, done: true });
        break;
      case 'tts': {
        if (!S.tts) throw new Error('no voice model loaded');
        let a;
        try { a = await S.tts.generate(m.text, { voice: m.voice, speed: m.speed || 1 }); } catch (err) { a = await S.tts.generate(m.text, { voice: 'af_bella', speed: m.speed || 1 }); }
        const pcm = a.audio instanceof Float32Array ? a.audio : new Float32Array(a.audio);
        post({ id, done: true, audio: pcm, sr: a.sampling_rate }, [pcm.buffer]);
        break;
      }
      case 'load-cap':
        S.cap = await withOrt(() => pipeline('image-to-text', m.hf, { device: 'wasm', progress_callback: prog(id) }));
        post({ id, done: true });
        break;
      case 'caption': {
        if (!S.cap) throw new Error('no vision model loaded');
        const r = await S.cap(m.image);
        post({ id, done: true, text: (r && r[0] && r[0].generated_text) || '' });
        break;
      }
      default: throw new Error('unknown request ' + m.type);
    }
  } catch (err) {
    post({ id, error: String((err && err.message) || err) });
  }
};
